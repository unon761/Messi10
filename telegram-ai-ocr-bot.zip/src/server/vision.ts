import { GoogleGenAI, Type } from "@google/genai";
import { CONFIG } from "./config.js";
import fs from "fs";
import { logger } from "./utils.js";

let _ai: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI {
  if (!_ai) {
    const key = CONFIG.GEMINI_API_KEY || process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY is missing. Please configure it in your environment variables or Settings > Secrets.");
    }
    _ai = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return _ai;
}

export interface PokemonGoAccountData {
  trainerLevel?: number;
  startDate?: string;
  totalXp?: string;
  xpProgress?: string;
  team?: string;
  trainerName?: string;
  friendCode?: string;
  stardust?: string;
  pokeCoins?: string;
  pokemonStorage?: string;
  itemStorage?: string;
  pokemonCaught?: string;
  pokestopsVisited?: string;
  distanceWalked?: string;
  shinyCount?: number;
  legendaryCount?: number;
  mythicalCount?: number;
  shadowCount?: number;
  purifiedCount?: number;
  luckyCount?: number;
  hundoCount?: number;
  hatchedCount?: number;
  eventCount?: number;
  megaCount?: number;
  dynamaxCount?: number;
  locationBackgroundCount?: number;
  specialBackgroundCount?: number;
  featuredPokemon?: Array<{ name: string; cp?: number; isShiny?: boolean; isLegendary?: boolean; isShadow?: boolean }>;
  premiumItems?: Array<{ name: string; count: number }>;
}

/**
 * Analyzes one or multiple Pokémon GO screenshots using Gemini 3.5 Flash vision.
 * Extracts structured account data cleanly and with high precision.
 */
export async function analyzeScreenshots(filePaths: string[]): Promise<PokemonGoAccountData> {
  if (filePaths.length === 0) {
    throw new Error("No screenshots provided for analysis.");
  }

  logger.info(`Analyzing ${filePaths.length} screenshot(s) via Gemini...`);

  // Prepare images as base64 inline parts for Gemini
  const parts: any[] = [];
  for (const filePath of filePaths) {
    if (!fs.existsSync(filePath)) {
      logger.warn(`Screenshot file not found: ${filePath}`);
      continue;
    }
    const data = fs.readFileSync(filePath);
    parts.push({
      inlineData: {
        data: data.toString("base64"),
        mimeType: "image/png",
      },
    });
  }

  if (parts.length === 0) {
    throw new Error("No valid screenshots were loaded.");
  }

  // Add the prompt instruction
  const promptPart = {
    text: `You are an expert OCR and image analysis system specialized in parsing Pokémon GO screenshots.
Analyze the provided screenshots of a Pokémon GO account and extract every visible statistic and asset.

Instructions:
1. Merge information from all screenshots into one cohesive account profile.
2. Only extract values that are actually visible in the screenshots. Do NOT guess, invent, or estimate missing numbers.
3. If multiple screenshots display the same field (e.g., Stardust or Trainer Level), keep the value with the highest clarity/confidence.
4. If a field or metric is not visible anywhere in the screenshots, return null or do not include it. Do not invent.
5. Pay close attention to specific labels:
   - "Stardust" is a number usually located near the bottom of the profile screen.
   - "Level" is the trainer level (integer between 1 and 50).
   - "PokéCoins" is the currency value.
   - "Pokémon Storage" and "Item Storage" are shown as "current/maximum" (e.g., "1250/1500").
   - "XP" represents Total XP or progress (keep the commas).
   - "Featured Pokémon" includes high CP, Shiny, Legendary, Shadow, or Rare Pokémon displayed in search grids or profile pages. Extract their name, and CP value if visible.
   - "Premium Items" includes premium items like Master Balls, Premium Passes, Lure Modules, Lucky Eggs, Star Pieces, Rocket Radars etc., along with their count if shown in the item list.
`,
  };

  parts.push(promptPart);

  try {
    const ai = getAiClient();
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: parts,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          description: "Structured statistics and collection of a Pokémon GO account.",
          properties: {
            trainerLevel: { type: Type.INTEGER, description: "Visible Trainer Level (1-50)" },
            startDate: { type: Type.STRING, description: "Start Date of the account" },
            totalXp: { type: Type.STRING, description: "Total Experience Points (XP) with commas" },
            xpProgress: { type: Type.STRING, description: "XP progress towards next level (e.g., '1,200,000 / 2,000,000')" },
            team: { type: Type.STRING, description: "Mystic, Valor, Instinct, or Harmony" },
            trainerName: { type: Type.STRING, description: "Visible trainer username" },
            friendCode: { type: Type.STRING, description: "12-digit friend code" },
            stardust: { type: Type.STRING, description: "Exact Stardust amount, keep formatting/commas" },
            pokeCoins: { type: Type.STRING, description: "Number of PokéCoins visible" },
            pokemonStorage: { type: Type.STRING, description: "Used/Max storage (e.g. '350/400')" },
            itemStorage: { type: Type.STRING, description: "Used/Max item storage" },
            pokemonCaught: { type: Type.STRING, description: "Total Pokémon caught statistic" },
            pokestopsVisited: { type: Type.STRING, description: "Total PokéStops visited statistic" },
            distanceWalked: { type: Type.STRING, description: "Total distance walked with units (e.g. '1,250.5 km')" },
            shinyCount: { type: Type.INTEGER, description: "Number of shiny Pokémon counted or search result total" },
            legendaryCount: { type: Type.INTEGER, description: "Number of legendary Pokémon" },
            mythicalCount: { type: Type.INTEGER, description: "Number of mythical Pokémon" },
            shadowCount: { type: Type.INTEGER, description: "Number of shadow Pokémon" },
            purifiedCount: { type: Type.INTEGER, description: "Number of purified Pokémon" },
            luckyCount: { type: Type.INTEGER, description: "Number of lucky Pokémon" },
            hundoCount: { type: Type.INTEGER, description: "Number of 100% IV (perfect) Pokémon" },
            hatchedCount: { type: Type.INTEGER, description: "Number of hatched Pokémon statistic" },
            eventCount: { type: Type.INTEGER, description: "Number of event or costume Pokémon" },
            megaCount: { type: Type.INTEGER, description: "Number of Mega-evolved or mega-capable Pokémon" },
            dynamaxCount: { type: Type.INTEGER, description: "Number of Dynamax / Gigantamax Pokémon" },
            locationBackgroundCount: { type: Type.INTEGER, description: "Number of Pokémon with location backgrounds" },
            specialBackgroundCount: { type: Type.INTEGER, description: "Number of Pokémon with special backgrounds" },
            featuredPokemon: {
              type: Type.ARRAY,
              description: "Notable rare Pokémon displayed in screenshots",
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING, description: "Full name of the Pokémon (e.g., 'Mewtwo')" },
                  cp: { type: Type.INTEGER, description: "Combat Power (CP) value" },
                  isShiny: { type: Type.BOOLEAN, description: "Is this Pokémon Shiny?" },
                  isLegendary: { type: Type.BOOLEAN, description: "Is this a Legendary Pokémon?" },
                  isShadow: { type: Type.BOOLEAN, description: "Is this a Shadow Pokémon?" },
                },
                required: ["name"],
              },
            },
            premiumItems: {
              type: Type.ARRAY,
              description: "Premium items visible in bags/inventory",
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING, description: "Name of item (e.g. 'Master Ball', 'Premium Battle Pass')" },
                  count: { type: Type.INTEGER, description: "Quantity of item visible" },
                },
                required: ["name", "count"],
              },
            },
          },
        },
      },
    });

    const textOutput = response.text;
    if (!textOutput) {
      throw new Error("No response text received from Gemini.");
    }

    const data: PokemonGoAccountData = JSON.parse(textOutput);
    logger.info("Screenshots parsed successfully by Gemini Vision.", data);
    return data;
  } catch (error: any) {
    logger.error("Error running Gemini vision parsing:", error);
    const errMessage = error.message || "";
    if (errMessage.includes("RESOURCE_EXHAUSTED") || errMessage.includes("quota") || error.status === 429 || errMessage.includes("429")) {
      throw new Error("Daily free trial API quota limit reached for screenshot analysis. Please try again in 1 minute, or ask the admin to link a paid premium key.");
    }
    throw error;
  }
}
