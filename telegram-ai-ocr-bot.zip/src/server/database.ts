import fs from "fs";
import path from "path";
import { CONFIG } from "./config.js";

export interface User {
  id: string;
  username: string;
  coins: number;
  free_trials_remaining: number;
  subscription_expiry: string | null;
  descriptions_generated: number;
  join_date: string;
}

export interface HistoryItem {
  id: number;
  user_id: string;
  timestamp: string;
  screenshots_count: number;
  description: string;
}

export interface QueueItem {
  id: number;
  user_id: string;
  file_path: string;
  timestamp: string;
}

// In-memory data structures
interface DbSchema {
  users: User[];
  description_history: HistoryItem[];
  temporary_upload_queue: QueueItem[];
  settings?: {
    group_chat_id?: string | null;
  };
}

const DATA_FILE = path.resolve(process.cwd(), "database.json");

let dbData: DbSchema = {
  users: [],
  description_history: [],
  temporary_upload_queue: [],
  settings: {
    group_chat_id: null,
  },
};

// Helper to load data from JSON
function loadData() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const content = fs.readFileSync(DATA_FILE, "utf-8");
      const parsed = JSON.parse(content);
      dbData = {
        users: parsed.users || [],
        description_history: parsed.description_history || [],
        temporary_upload_queue: parsed.temporary_upload_queue || [],
        settings: parsed.settings || { group_chat_id: null },
      };
    } else {
      saveData();
    }
  } catch (err) {
    console.error("Failed to load JSON database, resetting:", err);
    saveData();
  }
}

// Helper to save data to JSON
function saveData() {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(dbData, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to write JSON database:", err);
  }
}

// Initialise Database Tables (Stub for parity)
export async function initDb() {
  console.log("Initializing local JSON database...");
  loadData();
  console.log(`Loaded JSON database. Users: ${dbData.users.length}, History: ${dbData.description_history.length}, Queue: ${dbData.temporary_upload_queue.length}`);
}

// Check if subscription is currently active
export function isSubscriptionActive(expiry: string | null): boolean {
  if (!expiry) return false;
  const expiryDate = new Date(expiry);
  return expiryDate.getTime() > Date.now();
}

// Get or Create User
export async function getOrCreateUser(userId: string, username: string = "Trainer"): Promise<User> {
  loadData();
  let user = dbData.users.find((u) => u.id === userId);
  if (user) {
    if (username && user.username !== username) {
      user.username = username;
      saveData();
    }
    return user;
  }

  const joinDate = new Date().toISOString();
  const newUser: User = {
    id: userId,
    username,
    coins: 0,
    free_trials_remaining: CONFIG.FREE_COINS_LIMIT,
    subscription_expiry: null,
    descriptions_generated: 0,
    join_date: joinDate,
  };

  dbData.users.push(newUser);
  saveData();
  return newUser;
}

// Add Coins
export async function addCoins(userId: string, amount: number): Promise<void> {
  const user = await getOrCreateUser(userId);
  user.coins += amount;
  saveData();
}

// Remove Coins (Never below 0)
export async function removeCoins(userId: string, amount: number): Promise<void> {
  const user = await getOrCreateUser(userId);
  user.coins = Math.max(0, user.coins - amount);
  saveData();
}

// Add Subscription
export async function addSubscription(userId: string, plan: string): Promise<string> {
  const user = await getOrCreateUser(userId);
  
  let days = 0;
  switch (plan.toLowerCase()) {
    case "1d": days = 1; break;
    case "3d": days = 3; break;
    case "7d": days = 7; break;
    case "31d": days = 31; break;
    case "365d": days = 365; break;
    default: days = 1;
  }

  let baseDate = Date.now();
  if (user.subscription_expiry && isSubscriptionActive(user.subscription_expiry)) {
    baseDate = new Date(user.subscription_expiry).getTime();
  }

  const newExpiry = new Date(baseDate + days * 24 * 60 * 60 * 1000).toISOString();
  user.subscription_expiry = newExpiry;
  saveData();
  return newExpiry;
}

// Remove Subscription (Expire immediately)
export async function removeSubscription(userId: string): Promise<void> {
  const user = await getOrCreateUser(userId);
  user.subscription_expiry = null;
  saveData();
}

// Get Upload Queue
export async function getQueue(userId: string): Promise<QueueItem[]> {
  loadData();
  return dbData.temporary_upload_queue.filter((item) => item.user_id === userId);
}

// Add to Queue
export async function addToQueue(userId: string, filePath: string): Promise<void> {
  loadData();
  const nextId = dbData.temporary_upload_queue.reduce((max, item) => Math.max(max, item.id), 0) + 1;
  const timestamp = new Date().toISOString();
  const newItem: QueueItem = {
    id: nextId,
    user_id: userId,
    file_path: filePath,
    timestamp,
  };
  dbData.temporary_upload_queue.push(newItem);
  saveData();
}

// Clear Queue and delete physical files
export async function clearQueue(userId: string): Promise<void> {
  loadData();
  const userQueue = dbData.temporary_upload_queue.filter((item) => item.user_id === userId);
  for (const item of userQueue) {
    try {
      if (fs.existsSync(item.file_path)) {
        fs.unlinkSync(item.file_path);
      }
    } catch (e) {
      console.error("Error deleting temp screenshot:", e);
    }
  }
  dbData.temporary_upload_queue = dbData.temporary_upload_queue.filter((item) => item.user_id !== userId);
  saveData();
}

// Add Description History
export async function addHistory(userId: string, screenshotsCount: number, description: string): Promise<void> {
  loadData();
  const nextId = dbData.description_history.reduce((max, item) => Math.max(max, item.id), 0) + 1;
  const timestamp = new Date().toISOString();
  const newItem: HistoryItem = {
    id: nextId,
    user_id: userId,
    timestamp,
    screenshots_count: screenshotsCount,
    description,
  };
  dbData.description_history.push(newItem);

  // Update user stats
  const user = await getOrCreateUser(userId);
  user.descriptions_generated += 1;
  
  const hasSub = isSubscriptionActive(user.subscription_expiry);
  if (!hasSub) {
    if (user.free_trials_remaining > 0) {
      user.free_trials_remaining -= 1;
    } else {
      user.coins = Math.max(0, user.coins - 4);
    }
  }
  
  saveData();
}

// Get History
export async function getHistory(userId: string): Promise<HistoryItem[]> {
  loadData();
  return dbData.description_history
    .filter((item) => item.user_id === userId)
    .sort((a, b) => b.id - a.id);
}

// Get All Users (Admin Dashboard)
export async function getAllUsers(): Promise<User[]> {
  loadData();
  return [...dbData.users].sort((a, b) => new Date(b.join_date).getTime() - new Date(a.join_date).getTime());
}

// Get Group Chat ID
export function getGroupChatId(): string | null {
  loadData();
  return dbData.settings?.group_chat_id || process.env.TELEGRAM_GROUP_ID || null;
}

// Set Group Chat ID
export function setGroupChatId(chatId: string | null): void {
  loadData();
  if (!dbData.settings) {
    dbData.settings = {};
  }
  dbData.settings.group_chat_id = chatId;
  saveData();
}
