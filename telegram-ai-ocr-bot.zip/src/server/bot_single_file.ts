import express from "express";
import fs from "fs";
import path from "path";
import TelegramBot from "node-telegram-bot-api";
import Groq from "groq-sdk";
import { GoogleGenAI, Type } from "@google/genai";

/* ==========================================================================
   1. CONFIGURATION & KEYS
   ========================================================================== */
export const CONFIG = {
  // Configured Groq API Key
  GROQ_API_KEY: process.env.GROQ_API_KEY || "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",
  
  // Telegram Bot Token (Pass via environment variable TELEGRAM_BOT_TOKEN or paste here)
  TELEGRAM_BOT_TOKEN: process.env.TELEGRAM_BOT_TOKEN || "",
  
  // Gemini API Key for Vision & OCR fallback
  GEMINI_API_KEY: process.env.GEMINI_API_KEY || "",
  
  // Server Port
  PORT: process.env.PORT || 3000,
  
  // Database File Path
  DB_FILE: path.join(process.cwd(), "database.json"),
  TEMP_DIR: path.join(process.cwd(), "temp"),
};

// Ensure temp directory exists
if (!fs.existsSync(CONFIG.TEMP_DIR)) {
  fs.mkdirSync(CONFIG.TEMP_DIR, { recursive: true });
}

/* ==========================================================================
   2. LOCAL DATABASE persistence (JSON File)
   ========================================================================== */
export interface DbSchema {
  settings: {
    selectedModel: string;
    ocrAutoMode: boolean;
    botEnabled: boolean;
  };
  users: Record<string, { username?: string; firstName?: string; registeredAt: string }>;
  history: Array<{
    id: string;
    chatId: number;
    sender: "user" | "bot";
    text: string;
    timestamp: string;
    type?: "text" | "photo" | "ocr" | "description";
  }>;
  analysisRecords: Array<{
    id: string;
    chatId: number;
    extractedText?: string;
    description?: string;
    metadata?: any;
    timestamp: string;
  }>;
  stats: {
    messagesProcessed: number;
    imagesAnalyzed: number;
    ocrCompleted: number;
  };
}

const defaultDb: DbSchema = {
  settings: {
    selectedModel: "llama-3.3-70b-versatile",
    ocrAutoMode: true,
    botEnabled: true,
  },
  users: {},
  history: [],
  analysisRecords: [],
  stats: {
    messagesProcessed: 0,
    imagesAnalyzed: 0,
    ocrCompleted: 0,
  },
};

function loadDatabase(): DbSchema {
  try {
    if (fs.existsSync(CONFIG.DB_FILE)) {
      const data = fs.readFileSync(CONFIG.DB_FILE, "utf-8");
      return { ...defaultDb, ...JSON.parse(data) };
    }
  } catch (err) {
    console.error("Failed to load database.json, initializing default:", err);
  }
  return defaultDb;
}

function saveDatabase(db: DbSchema) {
  try {
    fs.writeFileSync(CONFIG.DB_FILE, JSON.stringify(db, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to save database.json:", err);
  }
}

const db = loadDatabase();

/* ==========================================================================
   3. GROQ & GEMINI AI CLIENT INITIALIZATION
   ========================================================================== */
function getGroqClient(): Groq {
  const key = CONFIG.GROQ_API_KEY;
  if (!key) {
    throw new Error("GROQ_API_KEY is not configured.");
  }
  return new Groq({ apiKey: key });
}

function getGeminiClient(): GoogleGenAI {
  const key = CONFIG.GEMINI_API_KEY;
  if (!key) {
    throw new Error("GEMINI_API_KEY is missing. Please configure GEMINI_API_KEY environment variable.");
  }
  return new GoogleGenAI({
    apiKey: key,
    httpOptions: { headers: { "User-Agent": "aistudio-build" } },
  });
}

/* ==========================================================================
   4. OCR, VISUAL EXTRACTION & AI DESCRIPTION ENGINE
   ========================================================================== */

export interface AnalysisResult {
  ocrText: string;
  visualDescription: string;
  structuredData?: any;
  formattedSalesListing?: string;
}

/**
 * Perform OCR Text Extraction and Visual AI Description on an image.
 */
export async function processImageWithVisionAndOCR(
  imageBuffer: Buffer,
  mimeType: string = "image/png",
  customPrompt?: string
): Promise<AnalysisResult> {
  console.log("Starting OCR & Visual AI Extraction...");
  const base64Image = imageBuffer.toString("base64");

  // Try Gemini Vision first for rich OCR & structured vision analysis
  if (CONFIG.GEMINI_API_KEY) {
    try {
      const ai = getGeminiClient();
      
      const promptText = customPrompt || `
You are an advanced AI Vision & OCR System. Perform a comprehensive analysis of this image:

1. 🔍 FULL OCR TEXT EXTRACTION:
Extract ALL readable text from the image verbatim (printed text, handwriting, signs, numbers, UI text, labels, tables). Format extracted text cleanly with headers and bullet points.

2. 🖼️ VISUAL SCENE & OBJECT DESCRIPTION:
Provide a detailed description of the visual scene, subject, colors, layout, logos, graphical elements, key objects, and overall context.

3. 📊 STRUCTURED DATA & KEY METRICS (If Applicable):
If the image contains stats (e.g. game profiles, Pokémon GO account statistics, invoices, receipts, documents, tables), extract all metrics into structured key-value pairs.

4. 💡 SUMMARY & KEY INSIGHTS:
A concise 2-3 sentence overview highlighting the main takeaway of the image.
`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: [
          {
            inlineData: {
              data: base64Image,
              mimeType: mimeType,
            },
          },
          { text: promptText },
        ],
      });

      const fullOutput = response.text || "No analysis generated.";

      // Also generate a tailored Telegram sales/account description if it looks like Pokémon GO or account stats
      let formattedSalesListing = "";
      try {
        formattedSalesListing = await generateGroqSalesDescription(fullOutput);
      } catch (e) {
        console.warn("Groq sales listing generation skipped:", e);
      }

      return {
        ocrText: extractSection(fullOutput, "OCR TEXT EXTRACTION") || fullOutput,
        visualDescription: fullOutput,
        formattedSalesListing: formattedSalesListing || undefined,
      };
    } catch (err) {
      console.error("Gemini Vision failed, attempting Groq fallback:", err);
    }
  }

  // Fallback to Groq Vision API
  try {
    const groq = getGroqClient();
    const chatCompletion = await groq.chat.completions.create({
      model: "llama-3.2-11b-vision-preview",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Extract all text (OCR) from this image verbatim, and then provide a detailed visual description of all objects, layout, stats, and text visible.",
            },
            {
              type: "image_url",
              image_url: {
                url: `data:${mimeType};base64,${base64Image}`,
              },
            },
          ],
        },
      ],
      temperature: 0.2,
    });

    const visionResult = chatCompletion.choices[0]?.message?.content || "No output from Groq Vision.";
    return {
      ocrText: visionResult,
      visualDescription: visionResult,
    };
  } catch (err: any) {
    console.error("Groq Vision API Error:", err);
    throw new Error(`Vision & OCR processing failed: ${err.message || err}`);
  }
}

/**
 * Generates an attractive sales or summary listing using Groq API
 */
export async function generateGroqSalesDescription(extractedContext: string): Promise<string> {
  const groq = getGroqClient();
  const completion = await groq.chat.completions.create({
    model: "llama-3.3-70b-versatile",
    messages: [
      {
        role: "system",
        content: "You are a professional copywriter and AI summarizer. Create a clean, visually appealing Telegram post based on the extracted image data.",
      },
      {
        role: "user",
        content: `Format the following extracted OCR & Vision data into a professional, clean Telegram post with clear section dividers, key stats, and bullet points:\n\n${extractedContext}`,
      },
    ],
    temperature: 0.3,
  });

  return completion.choices[0]?.message?.content || "";
}

function extractSection(text: string, sectionTitle: string): string {
  const regex = new RegExp(`${sectionTitle}[:\\n]+([\\s\\S]*?)(?=\\n\\n[0-9]+\\.|$)`, "i");
  const match = text.match(regex);
  return match ? match[1].trim() : "";
}

/* ==========================================================================
   5. TELEGRAM BOT BOT LOGIC
   ========================================================================== */
let bot: TelegramBot | null = null;

export function startTelegramBot() {
  const token = CONFIG.TELEGRAM_BOT_TOKEN;
  if (!token) {
    console.log("⚠️ TELEGRAM_BOT_TOKEN is not set. Telegram Bot is waiting for token configuration.");
    return;
  }

  try {
    bot = new TelegramBot(token, { polling: true });
    console.log("🚀 Telegram Bot successfully started and listening for messages!");

    // /start command
    bot.onText(/\/start/, (msg) => {
      const chatId = msg.chat.id;
      const welcomeMsg = `
👋 *Welcome to the AI Vision & OCR Telegram Bot!*

I am powered by *Groq AI* & *Advanced Vision OCR*.

*Available Features:*
📸 *Photo / Document Upload*: Send any image or screenshot for auto OCR & AI Description!
🔍 \`/ocr\` - Extract raw text from images
🖼️ \`/describe\` - Get detailed visual description & scene analysis
🤖 \`/model\` - Switch Groq AI Models
🧹 \`/clear\` - Reset chat conversation history
📊 \`/stats\` - View bot usage statistics
❓ \`/help\` - Show help menu

Send me a message or upload an image to get started!
`;
      bot?.sendMessage(chatId, welcomeMsg, { parse_mode: "Markdown" });
    });

    // /help command
    bot.onText(/\/help/, (msg) => {
      const chatId = msg.chat.id;
      bot?.sendMessage(chatId, "💡 *Help & Instructions*\n\n1. Send text messages to chat with Groq AI.\n2. Send any image, document, or screenshot to perform automatic OCR text extraction & AI visual description.", { parse_mode: "Markdown" });
    });

    // /stats command
    bot.onText(/\/stats/, (msg) => {
      const chatId = msg.chat.id;
      const statsMsg = `
📊 *Bot Usage Statistics*
━━━━━━━━━━━━━━━━━━
💬 *Messages Processed:* ${db.stats.messagesProcessed}
📸 *Images Analyzed:* ${db.stats.imagesAnalyzed}
📝 *OCR Tasks Completed:* ${db.stats.ocrCompleted}
🤖 *Active Groq Model:* \`${db.settings.selectedModel}\`
`;
      bot?.sendMessage(chatId, statsMsg, { parse_mode: "Markdown" });
    });

    // /clear command
    bot.onText(/\/clear/, (msg) => {
      const chatId = msg.chat.id;
      db.history = db.history.filter((h) => h.chatId !== chatId);
      saveDatabase(db);
      bot?.sendMessage(chatId, "🧹 *Chat history cleared!*", { parse_mode: "Markdown" });
    });

    // /model command - Inline keyboard to choose model
    bot.onText(/\/model/, (msg) => {
      const chatId = msg.chat.id;
      const opts = {
        reply_markup: {
          inline_keyboard: [
            [
              { text: "⚡ Llama 3.3 70B (Versatile)", callback_data: "model:llama-3.3-70b-versatile" },
              { text: "🚀 Llama 3.1 8B (Fast)", callback_data: "model:llama-3.1-8b-instant" },
            ],
            [
              { text: "💎 Mixtral 8x7b", callback_data: "model:mixtral-8x7b-32768" },
              { text: "👁️ Llama Vision 11B", callback_data: "model:llama-3.2-11b-vision-preview" },
            ],
          ],
        },
      };
      bot?.sendMessage(chatId, "🤖 *Select your preferred Groq Model:*", opts);
    });

    // Callback Query handler for model selection
    bot.on("callback_query", (query) => {
      if (query.data && query.data.startsWith("model:")) {
        const newModel = query.data.replace("model:", "");
        db.settings.selectedModel = newModel;
        saveDatabase(db);
        bot?.answerCallbackQuery(query.id, { text: `Model set to ${newModel}` });
        if (query.message) {
          bot?.sendMessage(query.message.chat.id, `✅ *Selected Model Updated:* \`${newModel}\``, { parse_mode: "Markdown" });
        }
      }
    });

    // Photo / Image Message Handler
    bot.on("photo", async (msg) => {
      const chatId = msg.chat.id;
      const photos = msg.photo;
      if (!photos || photos.length === 0) return;

      const highestResPhoto = photos[photos.length - 1];
      const fileId = highestResPhoto.file_id;

      bot?.sendMessage(chatId, "📸 *Image received!* Processing OCR text extraction and AI visual description...", { parse_mode: "Markdown" });

      try {
        // Download image from Telegram
        const fileLink = await bot?.getFileLink(fileId);
        if (!fileLink) throw new Error("Could not fetch image link from Telegram.");

        const res = await fetch(fileLink);
        const arrayBuffer = await res.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);

        // Run OCR and Vision analysis
        const result = await processImageWithVisionAndOCR(buffer, "image/png", msg.caption);

        // Update DB Stats
        db.stats.imagesAnalyzed++;
        db.stats.ocrCompleted++;
        db.analysisRecords.push({
          id: Date.now().toString(),
          chatId,
          extractedText: result.ocrText,
          description: result.visualDescription,
          timestamp: new Date().toISOString(),
        });
        saveDatabase(db);

        // Send Result Back to Telegram
        let outputMessage = `🔍 *OCR TEXT & VISUAL AI DESCRIPTION RESULT*\n━━━━━━━━━━━━━━━━━━\n\n`;
        outputMessage += result.visualDescription;

        if (result.formattedSalesListing) {
          outputMessage += `\n\n━━━━━━━━━━━━━━━━━━\n✨ *GENERATED AI LISTING*\n━━━━━━━━━━━━━━━━━━\n\n${result.formattedSalesListing}`;
        }

        // Split long messages if necessary
        if (outputMessage.length > 4000) {
          const chunks = outputMessage.match(/[\s\S]{1,3800}/g) || [outputMessage];
          for (const chunk of chunks) {
            await bot?.sendMessage(chatId, chunk);
          }
        } else {
          await bot?.sendMessage(chatId, outputMessage);
        }
      } catch (err: any) {
        console.error("Error processing photo in Telegram:", err);
        bot?.sendMessage(chatId, `❌ *Error processing image:* ${err.message || err}`);
      }
    });

    // General Text Chat Handler
    bot.on("message", async (msg) => {
      if (msg.photo || (msg.text && msg.text.startsWith("/"))) return; // Skip commands and photos handled elsewhere

      const chatId = msg.chat.id;
      const userText = msg.text || "";
      if (!userText.trim()) return;

      db.stats.messagesProcessed++;
      db.history.push({
        id: Date.now().toString(),
        chatId,
        sender: "user",
        text: userText,
        timestamp: new Date().toISOString(),
      });
      saveDatabase(db);

      try {
        bot?.sendChatAction(chatId, "typing");
        const groq = getGroqClient();

        // Prepare chat history context
        const userHistory = db.history
          .filter((h) => h.chatId === chatId)
          .slice(-6)
          .map((h) => ({
            role: h.sender === "user" ? ("user" as const) : ("assistant" as const),
            content: h.text,
          }));

        const completion = await groq.chat.completions.create({
          model: db.settings.selectedModel || "llama-3.3-70b-versatile",
          messages: [
            {
              role: "system",
              content: "You are a helpful, intelligent Telegram AI assistant powered by Groq. Provide clear, accurate, and structured answers.",
            },
            ...userHistory,
          ],
          temperature: 0.7,
        });

        const reply = completion.choices[0]?.message?.content || "I didn't receive a response.";

        db.history.push({
          id: Date.now().toString(),
          chatId,
          sender: "bot",
          text: reply,
          timestamp: new Date().toISOString(),
        });
        saveDatabase(db);

        bot?.sendMessage(chatId, reply);
      } catch (err: any) {
        console.error("Error in text chat:", err);
        bot?.sendMessage(chatId, `❌ *Error:* ${err.message || err}`);
      }
    });
  } catch (err) {
    console.error("Failed to initialize Telegram Bot:", err);
  }
}

/* ==========================================================================
   6. EXPRESS HTTP SERVER (Status API & Web Interface)
   ========================================================================== */
export function createExpressApp() {
  const app = express();
  app.use(express.json());

  // API Status & Configuration
  app.get("/api/status", (req, res) => {
    res.json({
      status: "online",
      hasGroqKey: !!CONFIG.GROQ_API_KEY,
      hasTelegramToken: !!CONFIG.TELEGRAM_BOT_TOKEN,
      hasGeminiKey: !!CONFIG.GEMINI_API_KEY,
      stats: db.stats,
      model: db.settings.selectedModel,
    });
  });

  // Get Chat History
  app.get("/api/history", (req, res) => {
    res.json({ history: db.history, analysisRecords: db.analysisRecords });
  });

  return app;
}

/* ==========================================================================
   7. MAIN ENTRYPOINT
   ========================================================================== */
if (import.meta.url === `file://${process.argv[1]}` || process.argv[1]?.endsWith("bot_single_file.ts")) {
  const app = createExpressApp();
  app.listen(CONFIG.PORT, () => {
    console.log(`🌐 Server listening on http://0.0.0.0:${CONFIG.PORT}`);
    startTelegramBot();
  });
}
