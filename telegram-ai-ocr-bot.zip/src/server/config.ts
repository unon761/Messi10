import dotenv from "dotenv";
dotenv.config();

export const CONFIG = {
  PORT: process.env.PORT ? parseInt(process.env.PORT, 10) : 3000,
  BOT_TOKEN: process.env.BOT_TOKEN || "",
  GROQ_API_KEY: process.env.GROQ_API_KEY || "",
  GEMINI_API_KEY: process.env.GEMINI_API_KEY || "",
  ADMIN_ID: process.env.ADMIN_ID || "7568676840", // Admin Telegram User ID
  FREE_COINS_LIMIT: 3,
  GENERATION_COST: 4,
  DB_PATH: "./database.sqlite",
};
