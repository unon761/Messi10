import TelegramBot from "node-telegram-bot-api";
import { CONFIG } from "./config.js";
import {
  getOrCreateUser,
  addCoins,
  removeCoins,
  addSubscription,
  removeSubscription,
  getQueue,
  addToQueue,
  clearQueue,
  addHistory,
  getHistory,
  isSubscriptionActive,
  getAllUsers,
  getGroupChatId,
  setGroupChatId,
} from "./database.js";
import { analyzeScreenshots } from "./vision.js";
import { generateAccountDescription } from "./groq_client.js";
import { logger } from "./utils.js";
import fs from "fs";

let bot: TelegramBot | null = null;
const lastReceiptMessageIdMap = new Map<string, number>();
const activeDownloadsMap = new Map<string, number>();
const uploadDebounceTimers = new Map<string, NodeJS.Timeout>();

export function getTelegramBotInstance(): TelegramBot | null {
  return bot;
}

/**
 * Safely sends a Telegram message. If Markdown parsing fails, it retries without Markdown parsing
 * to guarantee that the message is still delivered.
 */
export async function safeSendMessage(
  chatId: string | number,
  text: string,
  options: TelegramBot.SendMessageOptions = {}
): Promise<TelegramBot.Message | null> {
  if (!bot) {
    logger.warn(`[safeSendMessage] Bot is offline. Message not sent: ${text.substring(0, 50)}...`);
    return null;
  }
  try {
    return await bot.sendMessage(chatId, text, options);
  } catch (err: any) {
    // If it's a parsing error or 400 bad request, retry without parse_mode
    if (
      options.parse_mode === "Markdown" &&
      (err.message?.includes("can't parse entities") || err.message?.includes("bad request") || err.message?.includes("400"))
    ) {
      logger.warn(`[safeSendMessage] Markdown parsing failed, retrying without Markdown. Error: ${err.message}`);
      const fallbackOptions = { ...options };
      delete fallbackOptions.parse_mode;
      try {
        return await bot.sendMessage(chatId, text, fallbackOptions);
      } catch (fallbackErr: any) {
        logger.error(`[safeSendMessage] Fallback send failed:`, fallbackErr);
        throw fallbackErr;
      }
    } else {
      logger.error(`[safeSendMessage] Failed to send message:`, err);
      throw err;
    }
  }
}

/**
 * Main Telegram Bot Controller
 */
export async function startTelegramBot() {
  if (!CONFIG.BOT_TOKEN) {
    logger.warn("BOT_TOKEN is not configured in .env. The real Telegram bot will be offline, but you can fully test and run it using the Web UI Telegram Simulator!");
    return;
  }

  try {
    bot = new TelegramBot(CONFIG.BOT_TOKEN, { polling: true });
    logger.info("Telegram Bot connected and polling...");

    // Handlers for incoming text messages
    bot.on("message", async (msg) => {
      try {
        const chatType = msg.chat.type;
        const chatId = msg.chat.id.toString();
        const userId = msg.from?.id.toString();
        if (!userId) return;

        const username = msg.from?.username || msg.from?.first_name || "Trainer";
        const text = msg.text;

        // Skip messages that have photos, as we handle them in the photo event
        if (msg.photo) return;

        if (text) {
          const trimmed = text.trim();
          const isAdmin = userId === CONFIG.ADMIN_ID;

          // Command: /setgroup
          if (trimmed.startsWith("/setgroup")) {
            if (!isAdmin) {
              await safeSendMessage(chatId, "❌ *Access Denied:* Only the administrator can link groups.", { parse_mode: "Markdown" });
              return;
            }

            const parts = trimmed.split(/\s+/);
            let targetGroupId = chatId; // default to current chat if run in a group
            
            if (parts.length > 1) {
              targetGroupId = parts[1]; // custom ID specified (e.g. from private chat)
            } else if (chatType === "private") {
              await safeSendMessage(chatId, "💡 *Usage:* Send `/setgroup <group_id>` in private chat, or send `/setgroup` directly inside the target Telegram Group.", { parse_mode: "Markdown" });
              return;
            }

            setGroupChatId(targetGroupId);
            await safeSendMessage(chatId, `✅ *Telegram group successfully linked!* \n\n• *Group ID:* \`${targetGroupId}\`\n• This group will now receive transaction announcements for coins and subscriptions.`, { parse_mode: "Markdown" });
            return;
          }

          // If it is a group/supergroup, skip normal commands so the bot doesn't spam the group
          if (chatType === "group" || chatType === "supergroup") {
            return;
          }

          await handleIncomingCommand(userId, username, text, async (responseText) => {
            await safeSendMessage(userId, responseText, { parse_mode: "Markdown" });
          });
        }
      } catch (err) {
        logger.error("Failed to handle message event:", err);
      }
    });

    // Handler for incoming photo uploads
    bot.on("photo", async (msg) => {
      const userId = msg.from?.id.toString();
      if (!userId) return;

      const username = msg.from?.username || msg.from?.first_name || "Trainer";

      // Increment active downloads for this user
      const currentActive = activeDownloadsMap.get(userId) || 0;
      activeDownloadsMap.set(userId, currentActive + 1);

      // Clear any pending summary notifications since a new file has arrived
      const existingTimer = uploadDebounceTimers.get(userId);
      if (existingTimer) {
        clearTimeout(existingTimer);
        uploadDebounceTimers.delete(userId);
      }

      let downloadingMsg: TelegramBot.Message | null = null;
      try {
        // Get largest photo size
        const photo = msg.photo![msg.photo!.length - 1];
        
        // Notify user download started
        downloadingMsg = await safeSendMessage(userId, "📥 Downloading your screenshot... please wait.");
        
        // Download photo
        const localPath = await bot!.downloadFile(photo.file_id, "./temp");
        
        // Add to db queue
        await addToQueue(userId, localPath);

        // Delete individual loading message
        if (downloadingMsg) {
          try {
            await bot!.deleteMessage(userId, downloadingMsg.message_id);
          } catch (e) {
            // Ignore deletion failures
          }
        }
      } catch (error) {
        logger.error(`Failed to handle Telegram photo upload for user ${userId}:`, error);
        await safeSendMessage(userId, "❌ Failed to process screenshot. Please make sure it is a valid image and try again.");
      } finally {
        // Decrement active downloads
        const currentActive = activeDownloadsMap.get(userId) || 1;
        const newActive = Math.max(0, currentActive - 1);
        activeDownloadsMap.set(userId, newActive);

        // Clear existing timer if any (safety)
        const timerSec = uploadDebounceTimers.get(userId);
        if (timerSec) {
          clearTimeout(timerSec);
        }

        // Set a debounce timer to wait for any other incoming screenshots in this batch
        const timer = setTimeout(async () => {
          // Send notification only if all current concurrent downloads are complete
          if ((activeDownloadsMap.get(userId) || 0) === 0) {
            uploadDebounceTimers.delete(userId);
            try {
              const queue = await getQueue(userId);
              
              // If there was a previous summary message, delete it to keep chat history clean
              const previousMsgId = lastReceiptMessageIdMap.get(userId);
              if (previousMsgId) {
                try {
                  await bot!.deleteMessage(userId, previousMsgId);
                } catch (e) {
                  // Ignore deletion failures
                }
              }

              const newMsg = await safeSendMessage(
                userId,
                `✅ Screenshot received successfully!\n\n` +
                `• Total screenshots in your queue: *${queue.length}*\n` +
                `• Upload more screenshots if needed.\n\n` +
                `When finished, send: /generate`,
                { parse_mode: "Markdown" }
              );
              if (newMsg) {
                lastReceiptMessageIdMap.set(userId, newMsg.message_id);
              }
            } catch (err) {
              logger.error("Failed to send debounced queue message:", err);
            }
          }
        }, 2000); // 2 seconds debounce is optimal for both single and grouped uploads
        uploadDebounceTimers.set(userId, timer);
      }
    });

  } catch (error) {
    logger.error("Failed to start Telegram Bot:", error);
  }
}

/**
 * Central Command Handler - Executed by both the real Telegram bot and the Web Simulator.
 * This guarantees 100% logic and feature parity.
 */
export async function handleIncomingCommand(
  userId: string,
  username: string,
  text: string,
  reply: (msg: string) => Promise<void>
): Promise<void> {
  const parts = text.trim().split(/\s+/);
  const command = parts[0].toLowerCase();
  const args = parts.slice(1);

  // Load user
  const user = await getOrCreateUser(userId, username);
  const isAdmin = userId === CONFIG.ADMIN_ID;

  // ADMIN COMMANDS
  if (command.startsWith("/") && [
    "/addcoins", "/removecoins", "/addsub", "/removesub", "/userinfo"
  ].includes(command)) {
    if (!isAdmin) {
      await reply("❌ Access Denied: You do not have permission to execute administrator commands.");
      return;
    }

    try {
      if (command === "/addcoins") {
        const targetId = args[0];
        const amount = parseInt(args[1], 10);
        if (!targetId || isNaN(amount)) {
          await reply("Usage: `/addcoins <user_id> <amount>`");
          return;
        }
        await addCoins(targetId, amount);
        const updatedUser = await getOrCreateUser(targetId);
        const userDisplay = updatedUser.username && updatedUser.username !== "Trainer" 
          ? `@${updatedUser.username}` 
          : `Trainer (ID: ${targetId})`;
        await reply(`✅ Added *${amount}* coins to user *${targetId}*.`);
        await announceTransactionToGroup(
          `🔔 *TRANSACTION COMPLETED* 🔔\n\n` +
          `💰 Added *${amount}* Coins to user *${userDisplay}*.\n` +
          `✨ New Coins Balance: *${updatedUser.coins}* Coins.`
        );
        return;
      }

      if (command === "/removecoins") {
        const targetId = args[0];
        const amount = parseInt(args[1], 10);
        if (!targetId || isNaN(amount)) {
          await reply("Usage: `/removecoins <user_id> <amount>`");
          return;
        }
        await removeCoins(targetId, amount);
        const updatedUser = await getOrCreateUser(targetId);
        const userDisplay = updatedUser.username && updatedUser.username !== "Trainer" 
          ? `@${updatedUser.username}` 
          : `Trainer (ID: ${targetId})`;
        await reply(`✅ Removed *${amount}* coins (never below 0) from user *${targetId}*.`);
        await announceTransactionToGroup(
          `🔔 *TRANSACTION COMPLETED* 🔔\n\n` +
          `💸 Removed *${amount}* Coins from user *${userDisplay}*.\n` +
          `✨ New Coins Balance: *${updatedUser.coins}* Coins.`
        );
        return;
      }

      if (command === "/addsub") {
        const targetId = args[0];
        const plan = args[1]; // 1d, 3d, 7d, 31d, 365d
        if (!targetId || !plan) {
          await reply("Usage: `/addsub <user_id> <plan>`\nPlans: `1d`, `3d`, `7d`, `31d`, `365d`");
          return;
        }
        const expiry = await addSubscription(targetId, plan);
        const updatedUser = await getOrCreateUser(targetId);
        const userDisplay = updatedUser.username && updatedUser.username !== "Trainer" 
          ? `@${updatedUser.username}` 
          : `Trainer (ID: ${targetId})`;
        await reply(`✅ Subscription *${plan}* granted to *${targetId}*. Expiry date: *${new Date(expiry).toLocaleString()}*`);
        await announceTransactionToGroup(
          `🔔 *SUBSCRIPTION ACTIVATED* 🔔\n\n` +
          `🎉 Plan *${plan.toUpperCase()}* has been granted to user *${userDisplay}*.\n` +
          `📅 Valid Until: *${new Date(expiry).toLocaleString()}*.`
        );
        return;
      }

      if (command === "/removesub") {
        const targetId = args[0];
        if (!targetId) {
          await reply("Usage: `/removesub <user_id>`");
          return;
        }
        await removeSubscription(targetId);
        const updatedUser = await getOrCreateUser(targetId);
        const userDisplay = updatedUser.username && updatedUser.username !== "Trainer" 
          ? `@${updatedUser.username}` 
          : `Trainer (ID: ${targetId})`;
        await reply(`✅ Subscription expired/removed immediately for user *${targetId}*.`);
        await announceTransactionToGroup(
          `🔔 *SUBSCRIPTION REVOKED* 🔔\n\n` +
          `⚠️ Subscription has been revoked for user *${userDisplay}*.`
        );
        return;
      }

      if (command === "/userinfo") {
        const targetId = args[0] || userId; // Default to self info
        const targetUser = await getOrCreateUser(targetId);
        const subActive = isSubscriptionActive(targetUser.subscription_expiry);
        const expiryStr = targetUser.subscription_expiry 
          ? new Date(targetUser.subscription_expiry).toLocaleString() 
          : "None";

        await reply(
          `👤 *USER INFORMATION* 👤\n\n` +
          `• *User ID:* \`${targetUser.id}\`\n` +
          `• *Username:* @${targetUser.username || "None"}\n` +
          `• *Coins:* \`${targetUser.coins}\`\n` +
          `• *Free Trials Remaining:* \`${targetUser.free_trials_remaining}\`\n` +
          `• *Subscription Status:* ${subActive ? "🟢 Active" : "🔴 Inactive"}\n` +
          `• *Subscription Expiry:* \`${expiryStr}\`\n` +
          `• *Descriptions Generated:* \`${targetUser.descriptions_generated}\`\n` +
          `• *Join Date:* \`${new Date(targetUser.join_date).toLocaleDateString()}\``
        );
        return;
      }
    } catch (e: any) {
      logger.error("Admin command error:", e);
      await reply(`❌ Admin command error: ${e.message}`);
      return;
    }
  }

  // GENERAL USER COMMANDS
  switch (command) {
    case "/start":
      await reply(
        `👋 *Welcome to the Pokémon GO Description Writer Bot!* 👋\n\n` +
        `I generate premium, high-converting Pokémon GO account sale listings from your in-game screenshots using OCR, Vision AI, and Groq LLM!\n\n` +
        `🎁 *Your Balance:* You have *${user.free_trials_remaining}* free trial generations!\n\n` +
        `🚀 *How to use:* \n` +
        `1. Upload one or more screenshots of your Pokémon GO account (profile, storage, inventory, team screen, etc.).\n` +
        `2. I will queue them up.\n` +
        `3. Send /generate when you are ready.\n\n` +
        `Send /help to see all commands!`
      );
      break;

    case "/help":
      await reply(
        `📖 *POKÉMON GO BOT COMMAND GUIDE* 📖\n\n` +
        `⚡ *Core Commands:*\n` +
        `• /generate - Analyze your uploaded screenshots and write your premium description\n` +
        `• /balance - Check your available coins and free trials\n` +
        `• /subscription - Check your active subscription details\n` +
        `• /history - View your previously generated account summaries\n` +
        `• /buy - Find out how to purchase coins or a subscription plan\n` +
        `• /help - Display this command guide\n\n` +
        `💼 *Subscription Plans available:*\n` +
        `• 1 Day • 3 Days • 7 Days • 31 Days • 365 Days\n` +
        `Subscriptions give you *Unlimited Generations*!\n\n` +
        `🪙 *Coin Rates:*\n` +
        `After your 3 free trials are used up, each generation costs *4 Coins*.\n\n` +
        `${isAdmin ? `🛡️ *Admin Commands:*\n• \`/addcoins <id> <amount>\`\n• \`/removecoins <id> <amount>\`\n• \`/addsub <id> <plan>\`\n• \`/removesub <id>\`\n• \`/userinfo <id>\`\n\n` : ""}` +
        `📌 *Just upload your screenshots directly to get started!*`
      );
      break;

    case "/balance":
      await reply(
        `🪙 *YOUR BALANCE* 🪙\n\n` +
        `• *Free Trials Remaining:* \`${user.free_trials_remaining}\` generations\n` +
        `• *Coins Balance:* \`${user.coins}\` coins\n\n` +
        `💡 _Note: After free trials are exhausted, generating a description costs *4 coins*._`
      );
      break;

    case "/subscription": {
      const active = isSubscriptionActive(user.subscription_expiry);
      const expiryDate = user.subscription_expiry 
        ? new Date(user.subscription_expiry).toLocaleString() 
        : "None";

      await reply(
        `📅 *SUBSCRIPTION STATUS* 📅\n\n` +
        `• *Status:* ${active ? "🟢 *ACTIVE (Unlimited Access)*" : "🔴 *INACTIVE*"}\n` +
        `• *Expires on:* \`${expiryDate}\`\n\n` +
        `To activate or renew, send /buy.`
      );
      break;
    }

    case "/buy":
      await reply(
        `🪙 *COINS & SUBSCRIPTIONS PRESETS* 🪙\n\n` +
        `Need unlimited access or more coins to generate sales copy? Select a premium plan:\n\n` +
        `📦 *Subscription Plans (Unlimited Generations):*\n` +
        `• 🌟 *1 Day Access:* $1.99\n` +
        `• 🌟 *3 Days Access:* $3.99\n` +
        `• 🌟 *7 Days Access:* $6.99\n` +
        `• 🔥 *31 Days Access:* $14.99\n` +
        `• 👑 *365 Days Access:* $59.99\n\n` +
        `🪙 *Coin Packs:*\n` +
        `• 🎒 *Starter (10 Coins):* $0.99\n` +
        `• ⚔️ *Pro (50 Coins):* $3.99\n` +
        `• 🏆 *Elite (200 Coins):* $12.99\n\n` +
        `💬 *How to Purchase:*\n` +
        `Please contact our administrator @${CONFIG.ADMIN_ID === "7568676840" ? "PogoAdmin" : "Admin"} with your *User ID* (\`${userId}\`) to buy coins or a subscription. They will instantly credit your account!`
      );
      break;

    case "/history": {
      const history = await getHistory(userId);
      if (history.length === 0) {
        await reply("📭 You haven't generated any descriptions yet! Upload screenshots and send /generate to start.");
        return;
      }

      await reply(`📂 *GENERATION HISTORY* (${history.length} items):\n\nListing your latest generation below:`);
      // Return the most recent description
      await reply(history[0].description);
      break;
    }

    case "/generate": {
      const queue = await getQueue(userId);
      if (queue.length === 0) {
        await reply("❌ *No screenshots in queue!*\n\nPlease upload one or more screenshots first, then run /generate.");
        return;
      }

      // Clear the receipt message tracking since they are running generate now
      lastReceiptMessageIdMap.delete(userId);

      // Check balance / subscription first
      const hasSub = isSubscriptionActive(user.subscription_expiry);
      const hasFreeTrials = user.free_trials_remaining > 0;
      const hasCoins = user.coins >= 4;

      if (!hasSub && !hasFreeTrials && !hasCoins) {
        await reply(
          `❌ *Insufficient Balance!* ❌\n\n` +
          `• You have used all your free trials.\n` +
          `• You need at least *4 Coins* to generate. Current Balance: \`${user.coins}\` coins.\n` +
          `• No active subscription.\n\n` +
          `Send /buy to top-up coins or buy an unlimited subscription!`
        );
        return;
      }

      await reply(`⚙️ *Processing ${queue.length} screenshot(s)...*\nRunning OCR, merging account statistics, and generating your professional Groq description. This usually takes 5-10 seconds.`);

      try {
        const filePaths = queue.map((item) => item.file_path);
        
        // 1. OCR / Vision parsing via Gemini
        const accountData = await analyzeScreenshots(filePaths);

        // 2. Text generation via Groq (with Gemini fallback)
        const description = await generateAccountDescription(accountData);

        // 3. Save description to history and deduct tokens/coins
        await addHistory(userId, queue.length, description);

        // 4. Send final response
        await reply(description);

        // 5. Clean up local queue and temporary files
        await clearQueue(userId);

      } catch (error: any) {
        logger.error(`Error during /generate execution for user ${userId}:`, error);
        await reply(`❌ *Generation Failed!*\n\nAn error occurred while analyzing your screenshots or calling the AI. Please make sure the screenshots are clear and try again.\n\n_Details: ${error.message || "Internal error"}_`);
      }
      break;
    }

    default:
      if (command.startsWith("/")) {
        await reply("❓ Unknown command. Send /help to view all valid commands.");
      } else {
        // Ignored for non-command normal text in Telegram
      }
  }
}

/**
 * Announces a coin or subscription change to the configured Telegram Group.
 */
export async function announceTransactionToGroup(message: string): Promise<void> {
  const chatId = getGroupChatId();
  if (!chatId) {
    logger.info(`[Group Announcement] Skipped. No Telegram group ID configured yet. Message: ${message.replace(/\n/g, " ")}`);
    return;
  }

  if (!bot) {
    logger.warn(`[Group Announcement] Bot is offline/not initialized. Simulated Announcement: ${message.replace(/\n/g, " ")}`);
    return;
  }

  try {
    await safeSendMessage(chatId, message, { parse_mode: "Markdown" });
    logger.info(`[Group Announcement] Sent to group ${chatId}: ${message.replace(/\n/g, " ")}`);
  } catch (err: any) {
    logger.error(`[Group Announcement] Failed to send message to group ${chatId}:`, err);
  }
}
