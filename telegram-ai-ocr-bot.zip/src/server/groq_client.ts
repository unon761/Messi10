import Groq from "groq-sdk";
import { CONFIG } from "./config.js";
import { PokemonGoAccountData } from "./vision.js";
import { logger } from "./utils.js";
import { GoogleGenAI } from "@google/genai";

let _groq: Groq | null = null;

function getGroq(): Groq {
  if (!_groq) {
    const key = CONFIG.GROQ_API_KEY || process.env.GROQ_API_KEY;
    if (!key) {
      throw new Error("GROQ_API_KEY is missing. Please configure it in your environment variables or Settings > Secrets.");
    }
    _groq = new Groq({ apiKey: key });
  }
  return _groq;
}

/**
 * Generates the premium Pokémon GO account sale description.
 * It uses the Groq API (Llama model) to produce the description.
 * If GROQ_API_KEY is not configured, it gracefully falls back to Gemini API,
 * ensuring the bot never crashes and remains fully functional.
 */
export async function generateAccountDescription(data: PokemonGoAccountData): Promise<string> {
  const prompt = buildPrompt(data);

  // Check if we should use Groq or fall back to Gemini
  const groqKey = CONFIG.GROQ_API_KEY || process.env.GROQ_API_KEY;
  if (groqKey) {
    try {
      logger.info("Calling Groq API for description generation...");
      const groq = getGroq();
      const chatCompletion = await groq.chat.completions.create({
        messages: [
          {
            role: "system",
            content: "You are a professional Pokémon GO Account Appraiser and Sales copywriter. Your job is to format the extracted account data into a highly appealing, professional, clean, and factual sales description for Telegram.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        model: "llama-3.3-70b-versatile",
        temperature: 0.3, // Low temperature for maximum factual accuracy
      });

      const description = chatCompletion.choices[0]?.message?.content;
      if (description) {
        logger.info("Description generated successfully via Groq.");
        return description.trim();
      }
      throw new Error("Empty response from Groq.");
    } catch (error) {
      logger.error("Groq generation failed, falling back to Gemini:", error);
    }
  } else {
    logger.warn("GROQ_API_KEY is not configured. Falling back to Gemini API.");
  }

  // Fallback to Gemini API
  try {
    logger.info("Calling Gemini API as fallback for description generation...");
    const geminiKey = CONFIG.GEMINI_API_KEY || process.env.GEMINI_API_KEY;
    if (!geminiKey) {
      throw new Error("Neither GROQ_API_KEY nor GEMINI_API_KEY is configured.");
    }
    
    const ai = new GoogleGenAI({
      apiKey: geminiKey,
      httpOptions: {
        headers: { "User-Agent": "aistudio-build" },
      },
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are a professional Pokémon GO Account Appraiser and Sales copywriter. Your job is to format the extracted account data into a highly appealing, professional, clean, and factual sales description for Telegram.",
        temperature: 0.3,
      },
    });

    const description = response.text;
    if (description) {
      logger.info("Description generated successfully via Gemini Fallback.");
      return description.trim();
    }
    throw new Error("Empty response from Gemini Fallback.");
  } catch (error) {
    logger.error("Gemini Fallback generation failed:", error);
    throw new Error("Failed to generate description. Please check your API key configuration.");
  }
}

function buildPrompt(data: PokemonGoAccountData): string {
  return `You are given structured data parsed from screenshots of a Pokémon GO account. 
Your objective is to generate exactly ONE professional, cohesive sales listing using the target format below.

CRITICAL INSTRUCTIONS:
1. ONLY include fields and statistics that have values in the provided data.
2. If a field or metric is missing, null, or undefined, completely OMIT it from the output. Do NOT write "Not Available", "Unknown", "N/A", "None", or "Missing".
3. Never invent, estimate, hallucinate, or change numbers. Preserve all quantities, counts, and names exactly as provided.
4. If some resource or item is not mentioned in the structured data, do NOT list it.
5. Provide a short, captivating 2-3 sentence visual summary/highlights block right below the top header, focusing strictly on high stardust, high level, rare items, or specific shiny/legendary counts that are actually present.
6. The separators must be double spaced as shown below:
━━━━━━━━━━━━━━━━━━

🏆 ACCOUNT OVERVIEW

━━━━━━━━━━━━━━━━━━
7. Do NOT wrap your output in markdown code blocks like \`\`\` or any other tags. Output the raw formatted text directly.

Structured Account Data:
${JSON.stringify(data, null, 2)}

Target Telegram Format to Output:
---
🔥 POKÉMON GO ACCOUNT ON SALE 🔥

⚡ LEVEL {Trainer Level} ACCOUNT ⚡
🌈 {Shiny Count} Shinies • 👑 {Legendary Count} Legendaries • 💎 {Mythical Count} Mythicals • 🔥 {Shadow Count} Shadows • 🛡️ {Purified Count} Purified Pokémon ⚡

{Write a brief factual summary of the visible account highlights based only on the extracted data. Do not exaggerate or hallucinate.}

━━━━━━━━━━━━━━━━━━

🏆 ACCOUNT OVERVIEW

━━━━━━━━━━━━━━━━━━
⭐ Trainer Level: {Level}
📅 Start Date: {Start Date}
📈 Total XP: {Total XP}
🎯 XP Progress: {XP Progress}
⚡ Stardust: {Stardust}
🪙 PokéCoins: {PokéCoins}
🐾 Pokémon Caught: {Pokémon Caught}
🗺️ PokéStops Visited: {PokéStops Visited}
🚶 Distance Walked: {Distance Walked}
🎒 Pokémon Storage: {Pokémon Storage}
🎁 Item Storage: {Item Storage}

━━━━━━━━━━━━━━━━━━

✨ COLLECTION STATS

━━━━━━━━━━━━━━━━━━
🌈 {Shiny Count} Shiny Pokémon
👑 {Legendary Count} Legendary Pokémon
💎 {Mythical Count} Mythical Pokémon
🔥 {Shadow Count} Shadow Pokémon
🛡️ {Purified Count} Purified Pokémon
🍀 {Lucky Count} Lucky Pokémon
🎯 {Hundo Count} 100% IV Pokémon
🥚 {Hatched Count} Hatched Pokémon
🎉 {Event Count} Event Pokémon
🧬 {Mega Count} Mega-Evolvable Pokémon
⚡ {Dynamax Count} Dynamax Pokémon
🌍 {Location Background Count} Location Background Pokémon
❄️ {Special Background Count} Special Background Pokémon

━━━━━━━━━━━━━━━━━━

🔥 RARE & FEATURED POKÉMON

━━━━━━━━━━━━━━━━━━
List each Pokémon in the data's 'featuredPokemon' array, showing their name, CP, and attributes (e.g. ✨ Shiny, 👑 Legendary, 🔥 Shadow) only if present. Format as bullet points using ✨, 👑, 🌟, or appropriate emojis. E.g.:
✨ Shiny Mewtwo (CP {CP})
✨ Shiny Vaporeon
👑 Galarian Moltres Collection
🔥 Multiple Galarian Moltres with Location Background
🌟 Shadow Landorus (CP {CP})
⚡ Necrozma Collection
🌌 Cosmog ×{count}
🐉 Zygarde
If none are present, omit this entire section.

━━━━━━━━━━━━━━━━━━

⚡ ITEMS & RESOURCES

━━━━━━━━━━━━━━━━━━
💎 Stardust: {Stardust}
🪙 PokéCoins: {PokéCoins}
Include individual counts for Master Ball, Premium Battle Pass, Lucky Egg, Star Piece, Rare Candy, Rare Candy XL, Incense, etc. ONLY if they exist in 'premiumItems' list in the data. Format as item names with quantities. Omit if none. E.g.:
🎟️ Premium Battle Pass ×{count}
⭐ Star Piece ×{count}
🥚 Lucky Eggs ×{count}
🍬 Rare Candy ×{count}
🍬 Rare Candy XL ×{count}
🔥 Daily Adventure Incense ×{count}
🧿 Master Ball ×{count}
🎣 Lure Modules Available

━━━━━━━━━━━━━━━━━━

💥 WHY BUY THIS ACCOUNT?

━━━━━━━━━━━━━━━━━━
Generate a list of custom bullet points with ✅ based on the extracted data. Examples of points:
✅ Level {Level} Account Ready for Progression
✅ Rare {Featured Shiny/Legendary/etc.} Included
✅ {Legendary Count} Legendary Pokémon Collection
✅ {Other parsed features, e.g. "Multiple Galarian Moltres", "Shadow Legendary Landorus", "4 Dynamax Pokémon", "Master Ball Available"}
✅ Premium Raid Items Included
✅ Good Pokémon & Item Storage
✅ Excellent Account for Collectors and Players
✅ Screenshot Verified Collage Proof

🔥 ACCOUNT ON SALE — SERIOUS BUYERS ONLY! 🔥

📌 Complete screenshot proof included.
---

Remember:
- Omit any block, section, or line where the corresponding variable is missing or empty. Do NOT print placeholders like {Start Date} if Start Date is empty.
- Do not output anything other than the final listing. Do NOT wrap it in Markdown code blocks (like \`\`\`). Output raw text directly.`;
}
