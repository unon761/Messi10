import fs from "fs";
import path from "path";
import crypto from "crypto";

// Ensure required directories exist on boot
export function ensureDirectories() {
  const dirs = ["./temp", "./logs"];
  for (const dir of dirs) {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
      console.log(`Directory created: ${dir}`);
    }
  }
}

// Generate a safe unique filename for temporary uploads
export function generateTempFilename(userId: string, originalName?: string): string {
  const ext = originalName ? path.extname(originalName) : ".png";
  const uniqueId = crypto.randomBytes(8).toString("hex");
  return path.join("./temp", `${userId}_${uniqueId}${ext}`);
}

// Simple Logger with timestamps
export const logger = {
  info(message: string, ...meta: any[]) {
    const timestamp = new Date().toISOString();
    console.log(`[INFO] [${timestamp}] ${message}`, ...meta);
  },
  error(message: string, error?: any, ...meta: any[]) {
    const timestamp = new Date().toISOString();
    console.error(`[ERROR] [${timestamp}] ${message}`, error ? error : "", ...meta);
  },
  warn(message: string, ...meta: any[]) {
    const timestamp = new Date().toISOString();
    console.warn(`[WARN] [${timestamp}] ${message}`, ...meta);
  },
};
