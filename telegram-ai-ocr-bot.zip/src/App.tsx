import React, { useState, useEffect, useRef } from "react";
import {
  Send,
  Image as ImageIcon,
  Trash2,
  Coins,
  Calendar,
  User,
  Users,
  Settings,
  Shield,
  HelpCircle,
  History,
  Sparkles,
  Plus,
  Minus,
  Clock,
  Bot,
  Play,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  FileText,
  RefreshCw,
  CreditCard,
  Check,
  ShoppingBag,
  Download,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

// Structure for Simulated Telegram Message
interface ChatMessage {
  id: string;
  sender: "user" | "bot";
  text: string;
  timestamp: Date;
  isPending?: boolean;
}

// Structure for DB User
interface DBUser {
  id: string;
  username: string;
  coins: number;
  free_trials_remaining: number;
  subscription_expiry: string | null;
  descriptions_generated: number;
  join_date: string;
}

// Available Subscription plans for simulated checkout
const subscriptionPlans = [
  { id: "1d", name: "1 Day Pass", duration: "24 Hours Unlimited", price: 1.99, desc: "Perfect for testing out the generator features." },
  { id: "3d", name: "3 Day Pass", duration: "72 Hours Unlimited", price: 3.99, desc: "Great for weekend trainers selling multiple accounts." },
  { id: "7d", name: "Weekly Access", duration: "7 Days Unlimited", price: 6.99, desc: "Highly popular! Best for moderate sellers.", badge: "Recommended" },
  { id: "31d", name: "Monthly Elite", duration: "31 Days Unlimited", price: 14.99, desc: "Unlimited power for high-volume trade hubs.", badge: "Best Value" },
  { id: "365d", name: "Annual Pro Pass", duration: "365 Days Unlimited", price: 59.99, desc: "Maximum savings for elite account brokers." }
];

export default function App() {
  // Simulator State
  const [simulatorUserId, setSimulatorUserId] = useState<string>("7568676840"); // Default to Admin ID for easy testing
  const [simulatorUsername, setSimulatorUsername] = useState<string>("TrainerPro");
  const [inputText, setInputText] = useState<string>("");
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([
    {
      id: "1",
      sender: "bot",
      text: "👋 *Welcome to the Pokémon GO Description Writer Bot!* 👋\n\nI generate premium, high-converting Pokémon GO account sale listings from your in-game screenshots using OCR, Vision AI, and Groq LLM!\n\n🚀 *How to use:* \n1. Click the 🖼️ icon below or drag-and-drop to upload one or more screenshots.\n2. I will queue them up.\n3. Send `/generate` when you are ready.\n\nSend `/help` to see all commands!",
      timestamp: new Date(),
    },
  ]);
  const [queuedFilesCount, setQueuedFilesCount] = useState<number>(0);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  // System/Admin State
  const [systemStatus, setSystemStatus] = useState<any>({
    botOnline: false,
    secrets: { hasBotToken: false, hasGroqKey: false, hasGeminiKey: false },
    stats: { totalUsers: 0, adminUserId: "7568676840", groupChatId: null },
  });
  const [groupChatIdInput, setGroupChatIdInput] = useState<string>("");
  const [recentGroupAnnouncements, setRecentGroupAnnouncements] = useState<Array<{ id: string; text: string; timestamp: Date }>>([
    {
      id: "init",
      text: "📢 *Telegram Group Sync Engaged* \nLink a group ID using `/setgroup` in Telegram or configure below. Coin additions & subscriptions will be posted here live!",
      timestamp: new Date(),
    }
  ]);
  const [dbUsers, setDbUsers] = useState<DBUser[]>([]);
  const [selectedUser, setSelectedUser] = useState<DBUser | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [activeTab, setActiveTab] = useState<"admin" | "guide">("admin");
  const [newUserId, setNewUserId] = useState<string>("");
  const [newUserUsername, setNewUserUsername] = useState<string>("");

  // Subscription Purchase Modal State
  const [isPurchaseModalOpen, setIsPurchaseModalOpen] = useState<boolean>(false);
  const [purchasePlan, setPurchasePlan] = useState<string>("7d");
  const [isProcessingCheckout, setIsProcessingCheckout] = useState<boolean>(false);
  const [checkoutStep, setCheckoutStep] = useState<"select" | "pay" | "success">("select");

  // Simulated Card Fields
  const [cardHolder, setCardHolder] = useState<string>("TrainerPro");
  const [cardNumber, setCardNumber] = useState<string>("4111 2222 3333 4444");
  const [cardExpiry, setCardExpiry] = useState<string>("12/28");
  const [cardCvc, setCardCvc] = useState<string>("123");
  const [cardZip, setCardZip] = useState<string>("90210");
  const [purchaseExpiryDate, setPurchaseExpiryDate] = useState<string | null>(null);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync group chat input when state loads from API
  useEffect(() => {
    if (systemStatus.stats?.groupChatId) {
      setGroupChatIdInput(systemStatus.stats.groupChatId);
    }
  }, [systemStatus]);

  // Fetch initial data
  useEffect(() => {
    fetchStatus();
    fetchUsers();
  }, []);

  // Auto-scroll chat to bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatHistory]);

  const fetchStatus = async () => {
    try {
      const res = await fetch("/api/status");
      const data = await res.json();
      setSystemStatus(data);
    } catch (e) {
      console.error("Failed to fetch system status:", e);
    }
  };

  const fetchUsers = async () => {
    try {
      const res = await fetch("/api/admin/users");
      const data = await res.json();
      setDbUsers(data.users || []);
      
      // Update selected user if currently selected
      if (selectedUser) {
        const updated = data.users?.find((u: DBUser) => u.id === selectedUser.id);
        if (updated) setSelectedUser(updated);
      }
    } catch (e) {
      console.error("Failed to fetch DB users:", e);
    }
  };

  // Send message to the simulator API
  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend !== undefined ? textToSend : inputText;
    if (!text.trim()) return;

    if (textToSend === undefined) {
      setInputText("");
    }

    // Append user message
    const userMsg: ChatMessage = {
      id: Math.random().toString(),
      sender: "user",
      text,
      timestamp: new Date(),
    };
    setChatHistory((prev) => [...prev, userMsg]);

    // Append bot "typing..." state
    const pendingBotId = Math.random().toString();
    const pendingMsg: ChatMessage = {
      id: pendingBotId,
      sender: "bot",
      text: "⚡ Analyzing and generating...",
      timestamp: new Date(),
      isPending: true,
    };
    setChatHistory((prev) => [...prev, pendingMsg]);

    const isGenCommand = text.toLowerCase().trim() === "/generate";
    if (isGenCommand) {
      setIsGenerating(true);
    }

    try {
      const response = await fetch("/api/simulator/message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: simulatorUserId,
          username: simulatorUsername,
          text,
        }),
      });

      const data = await response.json();

      // Remove typing state and append real replies
      setChatHistory((prev) => prev.filter((m) => m.id !== pendingBotId));

      if (data.responses && data.responses.length > 0) {
        data.responses.forEach((respText: string, idx: number) => {
          setChatHistory((prev) => [
            ...prev,
            {
              id: `${Date.now()}-${idx}`,
              sender: "bot",
              text: respText,
              timestamp: new Date(),
            },
          ]);
        });
      } else {
        setChatHistory((prev) => [
          ...prev,
          {
            id: Math.random().toString(),
            sender: "bot",
            text: "❌ Empty response from the server.",
            timestamp: new Date(),
          },
        ]);
      }

      if (isGenCommand) {
        setQueuedFilesCount(0); // Queue cleared on successful /generate
      }

      // Refresh database tables
      fetchUsers();
      fetchStatus();
    } catch (error: any) {
      setChatHistory((prev) => prev.filter((m) => m.id !== pendingBotId));
      setChatHistory((prev) => [
        ...prev,
        {
          id: Math.random().toString(),
          sender: "bot",
          text: `❌ Error processing request: ${error.message || "Failed to reach server"}`,
          timestamp: new Date(),
        },
      ]);
    } finally {
      setIsGenerating(false);
    }
  };

  // Handle uploading screenshot via simulator
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    const formData = new FormData();
    formData.append("screenshot", file);
    formData.append("userId", simulatorUserId);

    try {
      const res = await fetch("/api/simulator/upload", {
        method: "POST",
        body: formData,
      });

      const data = await res.json();
      if (data.success) {
        setQueuedFilesCount(data.queueLength);
        setChatHistory((prev) => {
          const existingIndex = prev.findIndex(
            (msg) => msg.sender === "bot" && msg.text.includes("Screenshot received successfully!")
          );

          if (existingIndex !== -1) {
            const updated = [...prev];
            updated[existingIndex] = {
              ...updated[existingIndex],
              text: `✅ *Screenshot received successfully!*\n\n• Total screenshots in queue: *${data.queueLength}*\n• Upload more screenshots if needed.\n\nWhen finished, send: /generate`,
              timestamp: new Date(),
            };
            return updated;
          } else {
            return [
              ...prev,
              {
                id: Math.random().toString(),
                sender: "bot",
                text: `✅ *Screenshot received successfully!*\n\n• Total screenshots in queue: *${data.queueLength}*\n• Upload more screenshots if needed.\n\nWhen finished, send: /generate`,
                timestamp: new Date(),
              },
            ];
          }
        });
      } else {
        alert(data.error || "Failed to upload screenshot.");
      }
    } catch (err) {
      console.error(err);
      alert("Error uploading screenshot to simulator.");
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  // Admin Actions
  const handleAddCoins = async (userId: string, amount: number) => {
    try {
      const res = await fetch("/api/admin/coins", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, amount, action: "add" }),
      });
      if (res.ok) {
        const data = await res.json();
        fetchUsers();
        // Append simulated group announcement to local feed
        const u = data.user || dbUsers.find((user) => user.id === userId);
        const userDisplay = u?.username && u.username !== "Trainer" ? `@${u.username}` : `Trainer (ID: ${userId})`;
        setRecentGroupAnnouncements(prev => [
          {
            id: String(Date.now()),
            text: `🔔 *TRANSACTION COMPLETED* 🔔\n\n💰 Added *${amount}* Coins to user *${userDisplay}*.\n✨ New Coins Balance: *${u?.coins || (u ? u.coins + amount : amount)}* Coins.`,
            timestamp: new Date()
          },
          ...prev
        ]);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleRemoveCoins = async (userId: string, amount: number) => {
    try {
      const res = await fetch("/api/admin/coins", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, amount, action: "remove" }),
      });
      if (res.ok) {
        const data = await res.json();
        fetchUsers();
        // Append simulated group announcement to local feed
        const u = data.user || dbUsers.find((user) => user.id === userId);
        const userDisplay = u?.username && u.username !== "Trainer" ? `@${u.username}` : `Trainer (ID: ${userId})`;
        setRecentGroupAnnouncements(prev => [
          {
            id: String(Date.now()),
            text: `🔔 *TRANSACTION COMPLETED* 🔔\n\n💸 Removed *${amount}* Coins from user *${userDisplay}*.\n✨ New Coins Balance: *${u?.coins || 0}* Coins.`,
            timestamp: new Date()
          },
          ...prev
        ]);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddSubscription = async (userId: string, plan: string) => {
    try {
      const res = await fetch("/api/admin/subscription", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, plan }),
      });
      if (res.ok) {
        const data = await res.json();
        fetchUsers();
        // Append simulated group announcement to local feed
        const u = data.user || dbUsers.find((user) => user.id === userId);
        const userDisplay = u?.username && u.username !== "Trainer" ? `@${u.username}` : `Trainer (ID: ${userId})`;
        setRecentGroupAnnouncements(prev => [
          {
            id: String(Date.now()),
            text: `🔔 *SUBSCRIPTION ACTIVATED* 🔔\n\n🎉 Plan *${plan.toUpperCase()}* has been granted to user *${userDisplay}*.\n📅 Valid Until: *${new Date(data.expiry).toLocaleString()}*.`,
            timestamp: new Date()
          },
          ...prev
        ]);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleExpireSubscription = async (userId: string) => {
    try {
      const res = await fetch("/api/admin/subscription/expire", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId }),
      });
      if (res.ok) {
        const data = await res.json();
        fetchUsers();
        // Append simulated group announcement to local feed
        const u = data.user || dbUsers.find((user) => user.id === userId);
        const userDisplay = u?.username && u.username !== "Trainer" ? `@${u.username}` : `Trainer (ID: ${userId})`;
        setRecentGroupAnnouncements(prev => [
          {
            id: String(Date.now()),
            text: `🔔 *SUBSCRIPTION REVOKED* 🔔\n\n⚠️ Subscription has been revoked for user *${userDisplay}*.`,
            timestamp: new Date()
          },
          ...prev
        ]);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleClearQueue = async (userId: string) => {
    try {
      const res = await fetch("/api/admin/queue/clear", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId }),
      });
      if (res.ok && userId === simulatorUserId) {
        setQueuedFilesCount(0);
        alert("Screenshot queue cleared!");
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSaveGroupChatId = async () => {
    try {
      const res = await fetch("/api/admin/settings/group", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ groupChatId: groupChatIdInput }),
      });
      const data = await res.json();
      if (data.success) {
        setSystemStatus((prev: any) => ({
          ...prev,
          stats: {
            ...prev.stats,
            groupChatId: data.groupChatId,
          }
        }));
        alert("Telegram Announcement Group updated successfully!");
        setRecentGroupAnnouncements(prev => [
          {
            id: String(Date.now()),
            text: `✅ *Settings Updated*\n\nTelegram Group linked to ID: \`${data.groupChatId || "None"}\` successfully. Announcements are armed and live!`,
            timestamp: new Date()
          },
          ...prev
        ]);
      } else {
        alert("Failed to update group setting.");
      }
    } catch (e) {
      console.error(e);
      alert("Network error updating group setting.");
    }
  };

  const handlePurchaseSubscription = async () => {
    setIsProcessingCheckout(true);
    // Simulate payment gateway delay
    await new Promise((resolve) => setTimeout(resolve, 1500));
    try {
      const res = await fetch("/api/admin/subscription", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: simulatorUserId, plan: purchasePlan }),
      });
      const data = await res.json();
      if (data.success) {
        setPurchaseExpiryDate(data.expiry);
        setCheckoutStep("success");
        fetchUsers();
        fetchStatus();
        const planObj = subscriptionPlans.find((p) => p.id === purchasePlan);
        setChatHistory((prev) => [
          ...prev,
          {
            id: Math.random().toString(),
            sender: "bot",
            text: `🎉 *PAYMENT APPROVED & PLAN ACTIVATED!* 🎉\n\nThank you for purchasing the *${planObj?.name}*!\n\n• *User Name*: @${simulatorUsername}\n• *User ID*: \`${simulatorUserId}\`\n• *Subscription Tier*: ${planObj?.duration}\n• *Status*: Active (Unlimited generations enabled)\n• *Valid Until*: ${new Date(data.expiry).toLocaleString()}\n\nYou can now generate premium Pokémon GO listings. Type /generate or upload new screenshots to begin!`,
            timestamp: new Date(),
          },
        ]);

        // Append simulated group announcement to local feed
        setRecentGroupAnnouncements(prev => [
          {
            id: String(Date.now()),
            text: `🔔 *SUBSCRIPTION ACTIVATED* 🔔\n\n🎉 Plan *${purchasePlan.toUpperCase()}* has been granted to user *@${simulatorUsername}*.\n📅 Valid Until: *${new Date(data.expiry).toLocaleString()}*.`,
            timestamp: new Date()
          },
          ...prev
        ]);
      } else {
        alert(data.error || "Simulated credit card transaction failed.");
      }
    } catch (err: any) {
      console.error(err);
      alert("Error processing simulated checkout. Check network connection.");
    } finally {
      setIsProcessingCheckout(false);
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserId.trim()) return;
    try {
      const res = await fetch(`/api/admin/user/${newUserId.trim()}`);
      if (res.ok) {
        fetchUsers();
        setNewUserId("");
        setNewUserUsername("");
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Quick action presets for chat input
  const quickCommands = ["/start", "/help", "/balance", "/subscription", "/history", "/buy", "/generate"];

  // Filter registered users based on search
  const filteredUsers = dbUsers.filter(
    (u) =>
      u.id.includes(searchTerm) ||
      (u.username && u.username.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans" id="app-root">
      {/* Header Bar */}
      <header className="bg-slate-900 border-b border-slate-800 py-4 px-6 flex items-center justify-between" id="app-header">
        <div className="flex items-center space-x-3">
          <div className="bg-red-600 p-2 rounded-lg flex items-center justify-center text-white font-black text-xl shadow-lg shadow-red-600/20">
            P⚡Go
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight text-white flex items-center">
              Pokémon GO Description Bot
              <span className="ml-2 text-xs font-mono font-normal bg-red-950 text-red-400 border border-red-900/50 px-2 py-0.5 rounded-full">
                Dashboard
              </span>
            </h1>
            <p className="text-xs text-slate-400">Telegram Bot Management, Database & AI Playground</p>
          </div>
        </div>

        {/* System Health Indicators */}
        <div className="flex items-center space-x-6 text-sm">
          <div className="flex items-center space-x-2">
            <span className="text-xs text-slate-400">Bot Status:</span>
            {systemStatus.botOnline ? (
              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-emerald-950 text-emerald-400 border border-emerald-900/50">
                <span className="w-1.5 h-1.5 mr-1.5 bg-emerald-400 rounded-full animate-pulse" />
                Live Polling
              </span>
            ) : (
              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-amber-950 text-amber-400 border border-amber-900/50">
                <span className="w-1.5 h-1.5 mr-1.5 bg-amber-400 rounded-full animate-pulse" />
                Simulator-Only
              </span>
            )}
          </div>

          <div className="hidden md:flex items-center space-x-3">
            <div className="flex items-center space-x-1.5">
              <span className={`w-2 h-2 rounded-full ${systemStatus.secrets?.hasGeminiKey ? "bg-emerald-500" : "bg-red-500"}`} />
              <span className="text-xs text-slate-400">Gemini Vision</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className={`w-2 h-2 rounded-full ${systemStatus.secrets?.hasGroqKey ? "bg-emerald-500" : "bg-yellow-500"}`} />
              <span className="text-xs text-slate-400">Groq LLM</span>
            </div>
          </div>
          
          <a
            href="/api/download-zip"
            download="pokemon-go-bot-source.zip"
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white font-medium text-xs rounded-lg transition-colors shadow-sm shadow-red-600/30"
            title="Download full project source code as .zip"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download ZIP</span>
          </a>

          <button onClick={() => { fetchStatus(); fetchUsers(); }} className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-colors" title="Refresh Dashboard">
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Grid Content */}
      <main className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden h-[calc(100vh-73px)]" id="main-content">
        
        {/* Left Section: Live Telegram Simulator (60% width) */}
        <section className="lg:col-span-7 border-r border-slate-800 bg-slate-950/80 flex flex-col justify-between" id="simulator-section">
          
          {/* Simulator Bar Header */}
          <div className="bg-slate-900/50 border-b border-slate-800/80 py-3 px-5 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white relative">
                <Bot className="w-5 h-5" />
                <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-slate-900 rounded-full" />
              </div>
              <div>
                <h2 className="font-semibold text-slate-200 flex items-center">
                  @PogoDescWriterBot
                  <span className="ml-1.5 text-[10px] bg-blue-950 text-blue-400 border border-blue-900/50 px-1.5 py-0.2 rounded">Bot</span>
                </h2>
                <div className="flex items-center space-x-2 text-xs text-slate-400">
                  <span>Chat Simulator</span>
                  <span>•</span>
                  <span>Acting User:</span>
                  <select
                    className="bg-slate-800 text-slate-300 border border-slate-700 rounded px-1.5 py-0.5 text-xs outline-none cursor-pointer hover:border-slate-600"
                    value={simulatorUserId}
                    onChange={(e) => {
                      const uid = e.target.value;
                      setSimulatorUserId(uid);
                      const matchedUser = dbUsers.find(u => u.id === uid);
                      if (matchedUser) {
                        setSimulatorUsername(matchedUser.username || "Trainer");
                        setCardHolder(matchedUser.username || "Trainer");
                      } else {
                        setCardHolder("TrainerPro");
                      }
                      setChatHistory([
                        {
                          id: Math.random().toString(),
                          sender: "bot",
                          text: `🔄 Switched active simulator session to User ID \`${uid}\` (Coins: \`${matchedUser?.coins || 0}\`, Free Trials: \`${matchedUser?.free_trials_remaining || 0}\`).\n\nQueued screenshots will now be processed under this account.`,
                          timestamp: new Date()
                        }
                      ]);
                      setQueuedFilesCount(0);
                    }}
                  >
                    <option value="7568676840">7568676840 (Admin)</option>
                    {dbUsers.filter(u => u.id !== "7568676840").map(u => (
                      <option key={u.id} value={u.id}>{u.id} (@{u.username || "Trainer"})</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Simulated Queue Status & Store Trigger */}
            <div className="flex items-center space-x-3">
              <button
                type="button"
                onClick={() => {
                  setCheckoutStep("select");
                  setIsPurchaseModalOpen(true);
                }}
                className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center space-x-1.5 shadow-md shadow-emerald-900/20 transition-all cursor-pointer"
                title="Simulate Subscription Purchase"
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>Buy Plan</span>
              </button>

              <div className="text-right border-l border-slate-800 pl-3">
                <div className="text-xs text-slate-400">Temporary Queue</div>
                <div className="text-sm font-semibold text-sky-400 flex items-center justify-end">
                  <ImageIcon className="w-3.5 h-3.5 mr-1" />
                  {queuedFilesCount} Screenshot(s)
                </div>
              </div>
            </div>
          </div>

          {/* Chat Messages Log */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4 min-h-0 bg-slate-900/30">
            {chatHistory.map((msg) => {
              const isBot = msg.sender === "bot";
              return (
                <div key={msg.id} className={`flex ${isBot ? "justify-start" : "justify-end"}`}>
                  <div className={`flex items-start max-w-[85%] space-x-2 ${!isBot && "flex-row-reverse space-x-reverse"}`}>
                    
                    {/* Avatar */}
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs font-semibold ${isBot ? "bg-blue-600 text-white" : "bg-slate-700 text-slate-100"}`}>
                      {isBot ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                    </div>

                    {/* Message Bubble */}
                    <div className={`rounded-2xl px-4 py-3 shadow-md ${
                      isBot 
                        ? msg.isPending 
                          ? "bg-slate-800 text-slate-300 italic border border-slate-700/50 animate-pulse"
                          : "bg-slate-800 text-slate-200 border border-slate-700/50"
                        : "bg-blue-600 text-white"
                    }`}>
                      <div className="text-sm whitespace-pre-wrap leading-relaxed select-text select-all">
                        {/* Custom markdown formatter for simulated bot logs */}
                        {isBot ? (
                          msg.text.split("\n").map((line, i) => {
                            let formatted = line;
                            // Format markdown bold
                            formatted = formatted.replace(/\*(.*?)\*/g, "$1");
                            // Format backticks
                            formatted = formatted.replace(/`(.*?)`/g, "$1");
                            return <p key={i} className={line === "" ? "h-3" : ""}>{formatted}</p>;
                          })
                        ) : (
                          msg.text
                        )}
                      </div>
                      <div className={`text-[10px] mt-1.5 text-right ${isBot ? "text-slate-500" : "text-blue-200"}`}>
                        {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>

                  </div>
                </div>
              );
            })}
            <div ref={chatEndRef} />
          </div>

          {/* Quick Command Presets & Action Bar */}
          <div className="p-4 bg-slate-900/50 border-t border-slate-800/80 space-y-4">
            
            {/* Quick Presets */}
            <div className="flex flex-wrap gap-1.5">
              {quickCommands.map((cmd) => (
                <button
                  key={cmd}
                  onClick={() => handleSendMessage(cmd)}
                  disabled={isGenerating}
                  className={`text-xs px-2.5 py-1 rounded bg-slate-800 border hover:bg-slate-700 hover:border-slate-500 transition-colors ${
                    cmd === "/generate" 
                      ? "text-sky-400 border-sky-900/50 bg-sky-950/20 hover:bg-sky-900/30" 
                      : "text-slate-300 border-slate-700"
                  }`}
                >
                  {cmd}
                </button>
              ))}
            </div>

            {/* Chat Input / Attachment Controls */}
            <div className="flex items-center space-x-2">
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileUpload}
                accept="image/*"
                className="hidden"
              />
              
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading || isGenerating}
                className="p-3 bg-slate-800 border border-slate-700 hover:bg-slate-700 hover:border-slate-500 text-slate-300 rounded-xl flex items-center justify-center transition-colors disabled:opacity-50"
                title="Upload screenshot to bot queue"
              >
                {isUploading ? (
                  <RefreshCw className="w-5 h-5 animate-spin text-sky-400" />
                ) : (
                  <ImageIcon className="w-5 h-5" />
                )}
              </button>

              <div className="flex-1 relative">
                <input
                  type="text"
                  placeholder={
                    isGenerating 
                      ? "Generating Pokémon GO Listing... please wait 10s..." 
                      : "Type a command or text message..."
                  }
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                  disabled={isGenerating}
                  className="w-full bg-slate-950 border border-slate-800 hover:border-slate-700 focus:border-blue-500 focus:outline-none rounded-xl py-3 pl-4 pr-12 text-slate-200 placeholder-slate-500 text-sm transition-all"
                />
                
                <button
                  type="button"
                  onClick={() => handleSendMessage()}
                  disabled={isGenerating || !inputText.trim()}
                  className="absolute right-2 top-1.5 p-1.5 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-600 rounded-lg text-white transition-colors"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Disclaimer */}
            <p className="text-[10px] text-slate-500 text-center">
              💡 Drag & drop or attach images above, then click <strong className="text-sky-400">/generate</strong>. All processes are fully active and simulated via real database and Gemini.
            </p>
          </div>

        </section>

        {/* Right Section: Admin & Developer Panels (40% width) */}
        <section className="lg:col-span-5 flex flex-col bg-slate-900/30 overflow-hidden" id="admin-panel-section">
          
          {/* Tabs header */}
          <div className="flex border-b border-slate-800 bg-slate-900/40">
            <button
              onClick={() => setActiveTab("admin")}
              className={`flex-1 py-4 text-center font-semibold text-sm border-b-2 flex items-center justify-center space-x-2 transition-all ${
                activeTab === "admin"
                  ? "border-blue-500 text-white bg-slate-800/20"
                  : "border-transparent text-slate-400 hover:text-slate-200"
              }`}
            >
              <Shield className="w-4 h-4" />
              <span>Admin Database Panel</span>
            </button>
            <button
              onClick={() => setActiveTab("guide")}
              className={`flex-1 py-4 text-center font-semibold text-sm border-b-2 flex items-center justify-center space-x-2 transition-all ${
                activeTab === "guide"
                  ? "border-blue-500 text-white bg-slate-800/20"
                  : "border-transparent text-slate-400 hover:text-slate-200"
              }`}
            >
              <HelpCircle className="w-4 h-4" />
              <span>Guide & Architecture</span>
            </button>
          </div>

          {/* Active Tab Content */}
          <div className="flex-1 overflow-y-auto p-5 space-y-6">
            
            {activeTab === "admin" ? (
              <div className="space-y-6">
                
                {/* Search & Stats Summary */}
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
                  <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-3">
                    <span className="flex items-center">
                      <Users className="w-3.5 h-3.5 mr-1 text-slate-500" />
                      Total Database Users: <strong className="text-white ml-1">{dbUsers.length}</strong>
                    </span>
                    <span>Admin ID: <strong className="text-white font-mono">{systemStatus.stats?.adminUserId || "7568676840"}</strong></span>
                  </div>

                  <input
                    type="text"
                    placeholder="Search Users by ID or Username..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-xs text-slate-200 placeholder-slate-500 outline-none hover:border-slate-700 focus:border-blue-500 transition-colors"
                  />
                </div>

                {/* Telegram Group Integration Card */}
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
                  <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
                    <div className="p-1.5 bg-blue-900/40 text-blue-400 rounded-lg">
                      <Users className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-white uppercase tracking-wider">Telegram Group Integration</h3>
                      <p className="text-[10px] text-slate-400">Announce admin actions (coins & subscriptions) automatically</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase">Telegram Group Chat ID</label>
                    <div className="flex space-x-2">
                      <input
                        type="text"
                        placeholder="e.g. -100123456789"
                        value={groupChatIdInput}
                        onChange={(e) => setGroupChatIdInput(e.target.value)}
                        className="flex-1 bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-xs text-slate-200 placeholder-slate-600 outline-none hover:border-slate-700 focus:border-blue-500 transition-colors font-mono"
                      />
                      <button
                        onClick={handleSaveGroupChatId}
                        className="bg-blue-600 hover:bg-blue-500 text-white rounded-lg px-4 py-2 text-xs font-semibold transition-all shadow-md shadow-blue-500/10"
                      >
                        Link Group
                      </button>
                    </div>
                    <p className="text-[10px] text-slate-500 leading-relaxed">
                      💡 Tip: Add the bot to your Telegram group and send <code className="text-sky-400 font-mono">/setgroup</code> inside the group to auto-link, or copy the Chat ID manually here.
                    </p>
                  </div>

                  {/* Simulated Telegram Live feed */}
                  <div className="space-y-2 border-t border-slate-800 pt-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Group Notification Stream</span>
                      <span className="flex items-center text-[9px] text-emerald-400 font-semibold bg-emerald-950/40 border border-emerald-900 px-1.5 py-0.5 rounded">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse mr-1" />
                        Live Sync
                      </span>
                    </div>

                    <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-3 max-h-40 overflow-y-auto space-y-3 font-sans">
                      {recentGroupAnnouncements.length === 0 ? (
                        <p className="text-[11px] text-slate-600 text-center py-2">No transaction announcements sent yet.</p>
                      ) : (
                        recentGroupAnnouncements.map((ann) => (
                          <div key={ann.id} className="text-[11px] text-slate-300 border-b border-slate-900/60 pb-2 last:border-0 last:pb-0 leading-relaxed">
                            <div className="flex items-center justify-between text-[9px] text-slate-500 mb-1">
                              <span className="font-semibold text-sky-400 font-mono">TG GROUP CHAT</span>
                              <span>{new Date(ann.timestamp).toLocaleTimeString()}</span>
                            </div>
                            <div className="whitespace-pre-wrap bg-slate-900/40 rounded p-2 border border-slate-800/30 text-slate-200">
                              {ann.text.split("\n").map((line, idx) => {
                                // Simple markdown bold styling replacement for UI preview
                                let styled = line;
                                const bolds = line.match(/\*([^*]+)\*/g);
                                if (bolds) {
                                  bolds.forEach((match) => {
                                    const cleanText = match.slice(1, -1);
                                    styled = styled.replace(match, `<strong class="text-white">${cleanText}</strong>`);
                                  });
                                }
                                return (
                                  <p key={idx} dangerouslySetInnerHTML={{ __html: styled || "&nbsp;" }} />
                                );
                              })}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>

                {/* Users List */}
                <div className="space-y-2">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">Registered Users</h3>
                  
                  {filteredUsers.length === 0 ? (
                    <div className="bg-slate-900/40 border border-slate-800 border-dashed rounded-xl p-6 text-center text-xs text-slate-500">
                      No matching users found in the SQLite database.
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {filteredUsers.map((u) => {
                        const hasActiveSub = u.subscription_expiry && new Date(u.subscription_expiry).getTime() > Date.now();
                        const isSimSelected = u.id === simulatorUserId;

                        return (
                          <div
                            key={u.id}
                            onClick={() => setSelectedUser(u)}
                            className={`p-3 border rounded-xl text-left transition-all cursor-pointer ${
                              selectedUser?.id === u.id
                                ? "bg-slate-800 border-blue-500 shadow-md shadow-blue-500/5"
                                : "bg-slate-900 border-slate-800 hover:border-slate-700"
                            } ${isSimSelected && "ring-1 ring-emerald-500/40"}`}
                          >
                            <div className="flex items-start justify-between">
                              <div>
                                <h4 className="text-sm font-semibold text-white flex items-center">
                                  @{u.username || "Trainer"}
                                  {u.id === (systemStatus.stats?.adminUserId || "7568676840") && (
                                    <span className="ml-1.5 text-[9px] bg-red-950 text-red-400 border border-red-900 px-1 py-0.2 rounded font-mono font-normal">ADMIN</span>
                                  )}
                                  {isSimSelected && (
                                    <span className="ml-1 text-[9px] bg-emerald-950 text-emerald-400 border border-emerald-900 px-1 py-0.2 rounded font-mono font-normal">SIMULATOR ACTIVE</span>
                                  )}
                                </h4>
                                <p className="text-xs text-slate-400 font-mono mt-0.5">ID: {u.id}</p>
                              </div>
                              <div className="text-right">
                                {hasActiveSub ? (
                                  <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-900/50 px-2 py-0.5 rounded-full font-medium">
                                    🟢 UNLIMITED SUB
                                  </span>
                                ) : (
                                  <div className="flex items-center space-x-2 text-xs">
                                    <span className="text-slate-400">Coins: <strong className="text-white">{u.coins}</strong></span>
                                    <span className="text-slate-500">|</span>
                                    <span className="text-slate-400">Free: <strong className="text-white">{u.free_trials_remaining}</strong></span>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* User Detail & Control Form */}
                {selectedUser && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5"
                  >
                    <div className="flex justify-between items-start border-b border-slate-800 pb-3">
                      <div>
                        <h4 className="font-bold text-white text-base">Modify @{selectedUser.username}</h4>
                        <p className="text-xs text-slate-500 font-mono">ID: {selectedUser.id}</p>
                      </div>
                      <button
                        onClick={() => setSelectedUser(null)}
                        className="text-xs text-slate-500 hover:text-white"
                      >
                        Close
                      </button>
                    </div>

                    {/* Stats details */}
                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div className="bg-slate-950/50 p-2.5 rounded border border-slate-800/80">
                        <span className="text-slate-400">Join Date:</span>
                        <div className="font-medium text-slate-200 mt-0.5">
                          {new Date(selectedUser.join_date).toLocaleDateString()}
                        </div>
                      </div>
                      <div className="bg-slate-950/50 p-2.5 rounded border border-slate-800/80">
                        <span className="text-slate-400">Total Generated:</span>
                        <div className="font-medium text-slate-200 mt-0.5">
                          {selectedUser.descriptions_generated} listings
                        </div>
                      </div>
                    </div>

                    {/* Coins Manager */}
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center">
                        <Coins className="w-3.5 h-3.5 mr-1.5 text-yellow-500" />
                        Manage Coins Balance
                      </label>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleAddCoins(selectedUser.id, 10)}
                          className="flex-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 rounded border border-slate-700 font-medium flex items-center justify-center"
                        >
                          <Plus className="w-3 h-3 mr-1" /> Add 10 Coins
                        </button>
                        <button
                          onClick={() => handleAddCoins(selectedUser.id, 50)}
                          className="flex-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 rounded border border-slate-700 font-medium flex items-center justify-center"
                        >
                          <Plus className="w-3 h-3 mr-1" /> Add 50 Coins
                        </button>
                        <button
                          onClick={() => handleRemoveCoins(selectedUser.id, 4)}
                          className="flex-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 rounded border border-slate-700 font-medium flex items-center justify-center"
                        >
                          <Minus className="w-3 h-3 mr-1" /> Deduct 4 Coins
                        </button>
                      </div>
                    </div>

                    {/* Subscription Manager */}
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center">
                        <Calendar className="w-3.5 h-3.5 mr-1.5 text-emerald-500" />
                        Grant / Extend Unlimited Subscription
                      </label>
                      <div className="grid grid-cols-5 gap-1.5">
                        {["1d", "3d", "7d", "31d", "365d"].map((plan) => (
                          <button
                            key={plan}
                            onClick={() => handleAddSubscription(selectedUser.id, plan)}
                            className="py-1 bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 border border-slate-700 rounded"
                          >
                            {plan.toUpperCase()}
                          </button>
                        ))}
                      </div>
                      
                      {selectedUser.subscription_expiry && (
                        <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-800/60 text-xs">
                          <span className="text-slate-400">
                            Current Expiry: <strong className="text-slate-300 font-mono">{new Date(selectedUser.subscription_expiry).toLocaleDateString()}</strong>
                          </span>
                          <button
                            onClick={() => handleExpireSubscription(selectedUser.id)}
                            className="text-red-400 hover:text-red-300 font-medium"
                          >
                            Revoke Sub
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Queue Actions */}
                    <div className="pt-2 flex justify-between">
                      <button
                        onClick={() => {
                          setSimulatorUserId(selectedUser.id);
                          setSimulatorUsername(selectedUser.username || "Trainer");
                          alert(`Switched Active Simulator User to: @${selectedUser.username || "Trainer"}`);
                        }}
                        className="text-xs text-blue-400 hover:text-blue-300 font-medium"
                      >
                        Set as Active Simulator Session
                      </button>

                      <button
                        onClick={() => handleClearQueue(selectedUser.id)}
                        className="text-xs text-slate-400 hover:text-white flex items-center"
                      >
                        <Trash2 className="w-3 h-3 mr-1" /> Clear Temp Queue
                      </button>
                    </div>

                  </motion.div>
                )}

                {/* Create/Register User manually */}
                <form onSubmit={handleCreateUser} className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Register New Test User</h4>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="Telegram User ID (numeric)"
                      value={newUserId}
                      onChange={(e) => setNewUserId(e.target.value.replace(/\D/g, ""))}
                      className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 outline-none"
                    />
                    <input
                      type="text"
                      placeholder="Username (e.g. TrainerGo)"
                      value={newUserUsername}
                      onChange={(e) => setNewUserUsername(e.target.value)}
                      className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 outline-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-1.5 bg-blue-600 hover:bg-blue-500 text-xs font-semibold text-white rounded transition-colors"
                  >
                    Register User
                  </button>
                </form>

              </div>
            ) : (
              <div className="space-y-6 text-sm text-slate-300 leading-relaxed" id="guide-tab-content">
                
                {/* How OCR Vision AI Works */}
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
                  <h3 className="font-bold text-white flex items-center text-sm">
                    <Sparkles className="w-4 h-4 text-sky-400 mr-2" />
                    Multimodal Vision Analysis
                  </h3>
                  <p className="text-xs">
                    Unlike standard OCR tools that read flat text and hallucinate data positions, this bot leverages the state-of-the-art <strong>Gemini 3.5 Flash</strong> vision capabilities. It understands the actual Pokémon GO user interface directly from images.
                  </p>
                  <ul className="text-xs space-y-1.5 list-disc pl-4 text-slate-400">
                    <li>Recognizes item icons (e.g., Master Ball, Lucky Egg counts)</li>
                    <li>Accurately parses level charts, XP markers, and Trainer teams</li>
                    <li>Merges multiple screenshots (up to 10) into a single profile structure</li>
                    <li>Maintains absolute numeric fidelity and filters low-confidence guesses</li>
                  </ul>
                </div>

                {/* Flow Diagram */}
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
                  <h3 className="font-bold text-white flex items-center text-sm">
                    <FileText className="w-4 h-4 text-blue-400 mr-2" />
                    Description Pipeline Flow
                  </h3>
                  <div className="space-y-2.5 text-xs">
                    <div className="flex items-center space-x-3">
                      <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-200 flex items-center justify-center font-bold">1</span>
                      <span>Screenshots uploaded via Telegram / Web Queue</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-200 flex items-center justify-center font-bold">2</span>
                      <span>User executes <code>/generate</code> command</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-200 flex items-center justify-center font-bold">3</span>
                      <span>Gemini analyzes all screenshots and returns a clean JSON profile</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-200 flex items-center justify-center font-bold">4</span>
                      <span>Groq API processes the structured JSON and formats standard sales copy</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-200 flex items-center justify-center font-bold">5</span>
                      <span>Listing is sent to user; temp images deleted to conserve storage</span>
                    </div>
                  </div>
                </div>

                {/* Configuration & Deployment Files */}
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-gradient-to-r from-indigo-950 via-slate-900 to-purple-950 p-4 rounded-xl border border-indigo-500/30">
                    <div>
                      <h3 className="font-bold text-white flex items-center text-base">
                        <Download className="w-5 h-5 text-indigo-400 mr-2" />
                        Download Full Project Source Code (.ZIP)
                      </h3>
                      <p className="text-xs text-slate-300 mt-1">
                        Download the entire complete project repository containing all source code, backend files, configuration files, and package manifests ready to unzip and deploy.
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={async () => {
                          try {
                            const res = await fetch("/project.zip");
                            if (!res.ok) throw new Error("Server returned status " + res.status);
                            const blob = await res.blob();
                            const blobUrl = URL.createObjectURL(blob);
                            const a = document.createElement("a");
                            a.href = blobUrl;
                            a.download = "telegram-ai-ocr-bot.zip";
                            document.body.appendChild(a);
                            a.click();
                            document.body.removeChild(a);
                            URL.revokeObjectURL(blobUrl);
                          } catch (err) {
                            alert("Download error: " + err);
                          }
                        }}
                        className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-lg transition-all shadow-lg shadow-indigo-600/30 flex items-center justify-center space-x-2 cursor-pointer"
                      >
                        <Download className="w-4 h-4" />
                        <span>Download Full Project ZIP</span>
                      </button>
                    </div>
                  </div>

                  <h3 className="font-bold text-white flex items-center text-sm pt-2">
                    <Download className="w-4 h-4 text-emerald-400 mr-2" />
                    Individual Deployment & Requirements Files
                  </h3>
                  <p className="text-xs text-slate-400">
                    If deploying to <strong>Render</strong>, <strong>Replit</strong>, or <strong>Railway</strong>, download or copy individual configuration files below:
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
                    {/* bot.py card */}
                    <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 flex flex-col justify-between space-y-3">
                      <div>
                        <div className="font-bold text-slate-200 flex items-center justify-between">
                          <span>bot.py</span>
                          <span className="text-[10px] bg-sky-950 text-sky-400 border border-sky-800/50 px-2 py-0.5 rounded font-mono">Python Bot</span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-1">
                          Complete standalone Python implementation of the Telegram AI OCR bot.
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <button
                          type="button"
                          onClick={async () => {
                            try {
                              const res = await fetch("/bot.py");
                              if (!res.ok) throw new Error("Status " + res.status);
                              const blob = await res.blob();
                              const blobUrl = URL.createObjectURL(blob);
                              const a = document.createElement("a");
                              a.href = blobUrl;
                              a.download = "bot.py";
                              document.body.appendChild(a);
                              a.click();
                              document.body.removeChild(a);
                              URL.revokeObjectURL(blobUrl);
                            } catch (err) {
                              alert("Download error: " + err);
                            }
                          }}
                          className="flex-1 py-1.5 bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs rounded transition-colors flex items-center justify-center space-x-1 cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5 mr-1" />
                          <span>Download</span>
                        </button>
                      </div>
                    </div>

                    {/* package.json card */}
                    <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 flex flex-col justify-between space-y-3">
                      <div>
                        <div className="font-bold text-slate-200 flex items-center justify-between">
                          <span>package.json</span>
                          <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded">Node Manifest</span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-1">
                          Project configuration & dependencies for Node.js.
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <button
                          type="button"
                          onClick={async () => {
                            try {
                              const res = await fetch("/package.json");
                              if (!res.ok) throw new Error("Status " + res.status);
                              const blob = await res.blob();
                              const blobUrl = URL.createObjectURL(blob);
                              const a = document.createElement("a");
                              a.href = blobUrl;
                              a.download = "package.json";
                              document.body.appendChild(a);
                              a.click();
                              document.body.removeChild(a);
                              URL.revokeObjectURL(blobUrl);
                            } catch (err) {
                              alert("Download error: " + err);
                            }
                          }}
                          className="flex-1 py-1.5 bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs rounded transition-colors flex items-center justify-center space-x-1 cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5 mr-1" />
                          <span>Download</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            const pkgStr = JSON.stringify({
                              "name": "telegram-ai-ocr-bot",
                              "private": true,
                              "version": "1.0.0",
                              "type": "module",
                              "scripts": {
                                "dev": "tsx server.ts",
                                "build": "vite build && esbuild server.ts --bundle --platform=node --format=cjs --packages=external --sourcemap --outfile=dist/server.cjs",
                                "start": "node dist/server.cjs"
                              },
                              "dependencies": {
                                "@google/genai": "^0.1.1",
                                "cors": "^2.8.5",
                                "dotenv": "^16.4.7",
                                "express": "^4.21.2",
                                "groq-sdk": "^0.9.0",
                                "lucide-react": "^0.344.0",
                                "motion": "^12.4.7",
                                "node-telegram-bot-api": "^0.66.0",
                                "react": "^18.3.1",
                                "react-dom": "^18.3.1"
                              },
                              "devDependencies": {
                                "@types/cors": "^2.8.17",
                                "@types/express": "^4.17.21",
                                "@types/node": "^20.11.24",
                                "@types/node-telegram-bot-api": "^0.64.7",
                                "@types/react": "^18.2.61",
                                "@types/react-dom": "^18.2.45",
                                "@vitejs/plugin-react": "^4.2.1",
                                "autoprefixer": "^10.4.18",
                                "esbuild": "^0.25.0",
                                "postcss": "^8.4.35",
                                "tailwindcss": "^4.0.7",
                                "tsx": "^4.7.1",
                                "typescript": "^5.3.3",
                                "vite": "^5.1.4"
                              }
                            }, null, 2);
                            navigator.clipboard.writeText(pkgStr);
                            alert("Copied package.json content to clipboard!");
                          }}
                          className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs rounded border border-slate-700 transition-colors cursor-pointer"
                        >
                          Copy
                        </button>
                      </div>
                    </div>
                    {/* requirements.txt card */}
                    <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 flex flex-col justify-between space-y-3">
                      <div>
                        <div className="font-bold text-slate-200 flex items-center justify-between">
                          <span>requirements.txt</span>
                          <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded">Text File</span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-1">
                          Python dependencies for running the bot.
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <button
                          type="button"
                          onClick={async () => {
                            try {
                              const res = await fetch("/requirements.txt");
                              if (!res.ok) throw new Error("Status " + res.status);
                              const blob = await res.blob();
                              const blobUrl = URL.createObjectURL(blob);
                              const a = document.createElement("a");
                              a.href = blobUrl;
                              a.download = "requirements.txt";
                              document.body.appendChild(a);
                              a.click();
                              document.body.removeChild(a);
                              URL.revokeObjectURL(blobUrl);
                            } catch (err) {
                              alert("Download error: " + err);
                            }
                          }}
                          className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded transition-colors flex items-center justify-center space-x-1 cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5 mr-1" />
                          <span>Download</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(`pyTelegramBotAPI>=4.26.0\ngroq>=0.11.0\nrequests>=2.31.0\npython-dotenv>=1.0.0\nPillow>=10.0.0\n`);
                            alert("Copied requirements.txt content to clipboard!");
                          }}
                          className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs rounded border border-slate-700 transition-colors cursor-pointer"
                        >
                          Copy
                        </button>
                      </div>
                    </div>

                    {/* render.yaml card */}
                    <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 flex flex-col justify-between space-y-3">
                      <div>
                        <div className="font-bold text-slate-200 flex items-center justify-between">
                          <span>render.yaml</span>
                          <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded">Render Config</span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-1">
                          Configures Render Node environment & build scripts automatically.
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <button
                          type="button"
                          onClick={() => {
                            const link = document.createElement("a");
                            const content = `services:\n  - type: web\n    name: telegram-ai-ocr-bot\n    env: node\n    plan: free\n    rootDir: .\n    buildCommand: npm install && npm run build\n    startCommand: npm start\n    envVars:\n      - key: TELEGRAM_BOT_TOKEN\n        sync: false\n      - key: GROQ_API_KEY\n        sync: false\n      - key: GEMINI_API_KEY\n        sync: false\n      - key: NODE_VERSION\n        value: 20.10.0\n`;
                            const blob = new Blob([content], { type: "text/yaml" });
                            link.href = URL.createObjectURL(blob);
                            link.download = "render.yaml";
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                          }}
                          className="flex-1 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs rounded transition-colors flex items-center justify-center space-x-1 cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5 mr-1" />
                          <span>Download</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(`services:\n  - type: web\n    name: telegram-ai-ocr-bot\n    env: node\n    plan: free\n    rootDir: .\n    buildCommand: npm install && npm run build\n    startCommand: npm start\n    envVars:\n      - key: TELEGRAM_BOT_TOKEN\n        sync: false\n      - key: GROQ_API_KEY\n        sync: false\n      - key: GEMINI_API_KEY\n        sync: false\n      - key: NODE_VERSION\n        value: 20.10.0\n`);
                            alert("Copied render.yaml content to clipboard!");
                          }}
                          className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs rounded border border-slate-700 transition-colors cursor-pointer"
                        >
                          Copy
                        </button>
                      </div>
                    </div>

                    {/* yarn.lock card */}
                    <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 flex flex-col justify-between space-y-3">
                      <div>
                        <div className="font-bold text-slate-200 flex items-center justify-between">
                          <span>yarn.lock</span>
                          <span className="text-[10px] bg-slate-800 text-amber-400 px-2 py-0.5 rounded">Yarn Lockfile</span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-1">
                          Forces deployment platforms to build with Yarn package manager.
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <button
                          type="button"
                          onClick={() => {
                            const link = document.createElement("a");
                            link.href = "/yarn.lock";
                            link.download = "yarn.lock";
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                          }}
                          className="flex-1 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs rounded transition-colors flex items-center justify-center space-x-1 cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5 mr-1" />
                          <span>Download</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(`# THIS IS AN AUTOGENERATED FILE. DO NOT EDIT DIRECTLY.\n# yarn lockfile v1\n`);
                            alert("Copied yarn.lock content to clipboard!");
                          }}
                          className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs rounded border border-slate-700 transition-colors cursor-pointer"
                        >
                          Copy
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Render Root Directory Fix Guide */}
                <div className="bg-red-950/40 border border-red-800/60 rounded-xl p-4 space-y-3">
                  <h3 className="font-bold text-red-200 flex items-center text-sm">
                    <AlertCircle className="w-4 h-4 text-red-400 mr-2" />
                    Fix Render Error: "Couldn't find a package.json file in /opt/render/project/src"
                  </h3>
                  <div className="text-xs text-red-200/90 space-y-2 leading-relaxed">
                    <p>
                      This error happens when Render's <strong>"Root Directory"</strong> setting is incorrectly set to <code>src</code> instead of leaving it blank.
                    </p>
                    <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1.5 font-mono text-[11px] text-slate-300">
                      <p><strong className="text-amber-400">1. Root Directory:</strong> Leave BLANK / Empty (or set to <code>.</code>)</p>
                      <p><strong className="text-amber-400">2. Environment:</strong> Node</p>
                      <p><strong className="text-amber-400">3. Build Command:</strong> <code>npm install && npm run build</code> <span className="text-slate-500">(or <code>yarn && yarn build</code>)</span></p>
                      <p><strong className="text-amber-400">4. Start Command:</strong> <code>npm start</code> <span className="text-slate-500">(or <code>yarn start</code>)</span></p>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Go to your Render Dashboard → Select your Web Service → <strong>Settings</strong> → Set <strong>Root Directory</strong> to blank (clear any text) → Click <strong>Save Changes</strong> and redeploy!
                    </p>
                  </div>
                </div>

                {/* Configuration guide */}
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
                  <h3 className="font-bold text-white flex items-center text-sm">
                    <Settings className="w-4 h-4 text-yellow-500 mr-2" />
                    Environment Variables Setup
                  </h3>
                  <p className="text-xs text-slate-400">
                    To host this bot live, set these environment variables in your hosting dashboard (Render / Replit / Railway):
                  </p>
                  <div className="bg-slate-950 p-2.5 rounded font-mono text-[11px] text-slate-300 select-all border border-slate-800">
                    <div className="text-slate-500"># Telegram Bot API token from @BotFather</div>
                    TELEGRAM_BOT_TOKEN="your_telegram_bot_token"
                    <br />
                    <br />
                    <div className="text-slate-500"># Groq API Key for Llama listing generation</div>
                    GROQ_API_KEY="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"
                    <br />
                    <br />
                    <div className="text-slate-500"># Google Gemini key for Vision OCR</div>
                    GEMINI_API_KEY="your_gemini_api_key"
                  </div>
                </div>

              </div>
            )}

          </div>

          {/* Footer branding */}
          <div className="p-4 bg-slate-900/60 border-t border-slate-800 text-center text-xs text-slate-500">
            Pokémon GO Description Bot • Crafted professionally
          </div>

        </section>

      </main>

      {/* Interactive Subscription Purchase Modal */}
      {isPurchaseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            
            {/* Header */}
            <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
              <div className="flex items-center space-x-2">
                <ShoppingBag className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-lg text-white">Simulated Subscription Store</h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  if (!isProcessingCheckout) {
                    setIsPurchaseModalOpen(false);
                    setCheckoutStep("select");
                  }
                }}
                className="text-slate-400 hover:text-white hover:bg-slate-800 p-1.5 rounded-lg transition-all cursor-pointer"
                disabled={isProcessingCheckout}
              >
                <Plus className="w-5 h-5 rotate-45" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              
              {/* Step 1: Select Plan */}
              {checkoutStep === "select" && (
                <div className="space-y-4">
                  <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/80 text-xs space-y-2">
                    <div className="text-slate-400">Purchasing for Acting Simulator User:</div>
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-white text-sm">@{simulatorUsername}</span>
                      <span className="font-mono text-slate-500">ID: {simulatorUserId}</span>
                    </div>
                  </div>

                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Choose a Subscription Tier</h4>
                  
                  <div className="space-y-2.5">
                    {subscriptionPlans.map((plan) => {
                      const isSelected = purchasePlan === plan.id;
                      return (
                        <div
                          key={plan.id}
                          onClick={() => setPurchasePlan(plan.id)}
                          className={`p-4 rounded-xl border transition-all cursor-pointer relative ${
                            isSelected
                              ? "bg-slate-850/60 border-emerald-500 ring-1 ring-emerald-500/20"
                              : "bg-slate-950/20 border-slate-800 hover:border-slate-700"
                          }`}
                        >
                          {plan.badge && (
                            <span className="absolute top-3 right-3 text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800/50 px-2.5 py-0.5 rounded-full font-semibold">
                              {plan.badge}
                            </span>
                          )}

                          <div className="flex items-start justify-between pr-20">
                            <div>
                              <h5 className="font-semibold text-white text-sm flex items-center">
                                {plan.name}
                                {isSelected && <Check className="w-4 h-4 text-emerald-400 ml-2" />}
                              </h5>
                              <p className="text-xs text-slate-400 mt-0.5">{plan.desc}</p>
                              <div className="text-[11px] text-slate-500 font-mono mt-1">{plan.duration}</div>
                            </div>
                            <div className="text-right">
                              <span className="text-base font-bold text-emerald-400">${plan.price}</span>
                              <span className="text-[10px] text-slate-500 block font-normal">one-time</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <button
                    type="button"
                    onClick={() => setCheckoutStep("pay")}
                    className="w-full mt-4 py-3 bg-emerald-600 hover:bg-emerald-500 text-sm font-bold text-white rounded-xl transition-colors shadow-lg shadow-emerald-900/10 flex items-center justify-center space-x-2 cursor-pointer"
                  >
                    <span>Proceed to Simulated Checkout</span>
                    <CreditCard className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* Step 2: Pay with simulated Card */}
              {checkoutStep === "pay" && (
                <div className="space-y-5">
                  
                  {/* Virtual Credit Card Display */}
                  <div className="bg-gradient-to-br from-emerald-600 via-teal-700 to-blue-800 rounded-2xl p-5 shadow-lg relative text-white space-y-6">
                    <div className="flex justify-between items-start">
                      <div className="font-bold tracking-widest text-xs uppercase opacity-85">Simulated Card</div>
                      <div className="bg-white/20 p-1.5 rounded-lg text-[10px] font-mono">VISA</div>
                    </div>

                    <div className="space-y-1">
                      <div className="text-xs opacity-60 font-mono">Card Number</div>
                      <div className="text-lg font-mono tracking-widest">{cardNumber || "•••• •••• •••• ••••"}</div>
                    </div>

                    <div className="flex justify-between items-end">
                      <div className="space-y-0.5">
                        <div className="text-[10px] opacity-60 uppercase font-mono">Cardholder</div>
                        <div className="text-sm font-semibold tracking-wide truncate max-w-[180px]">{cardHolder || "TRAINER PRO"}</div>
                      </div>
                      <div className="flex space-x-4">
                        <div className="space-y-0.5">
                          <div className="text-[9px] opacity-60 uppercase font-mono">Expires</div>
                          <div className="text-xs font-mono">{cardExpiry || "MM/YY"}</div>
                        </div>
                        <div className="space-y-0.5">
                          <div className="text-[9px] opacity-60 uppercase font-mono">CVC</div>
                          <div className="text-xs font-mono">{cardCvc || "•••"}</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Form inputs */}
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 gap-3 text-xs">
                      <div className="space-y-1">
                        <label className="text-slate-400 font-medium">Cardholder Name</label>
                        <input
                          type="text"
                          value={cardHolder}
                          onChange={(e) => setCardHolder(e.target.value)}
                          placeholder="Your full name"
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2.5 px-3.5 text-slate-200 focus:border-emerald-500 focus:outline-none"
                          disabled={isProcessingCheckout}
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-slate-400 font-medium">Card Number</label>
                        <input
                          type="text"
                          value={cardNumber}
                          onChange={(e) => {
                            let val = e.target.value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
                            let matches = val.match(/\d{4,16}/g);
                            let match = (matches && matches[0]) || "";
                            let parts = [];
                            for (let i = 0, len = match.length; i < len; i += 4) {
                              parts.push(match.substring(i, i + 4));
                            }
                            if (parts.length > 0) {
                              setCardNumber(parts.join(" "));
                            } else {
                              setCardNumber(val);
                            }
                          }}
                          placeholder="4111 2222 3333 4444"
                          maxLength={19}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2.5 px-3.5 text-slate-200 font-mono focus:border-emerald-500 focus:outline-none"
                          disabled={isProcessingCheckout}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-3 text-xs">
                      <div className="space-y-1 col-span-1">
                        <label className="text-slate-400 font-medium">Expiry Date</label>
                        <input
                          type="text"
                          value={cardExpiry}
                          onChange={(e) => {
                            let val = e.target.value.replace(/[^0-9]/g, "");
                            if (val.length >= 2) {
                              setCardExpiry(val.substring(0, 2) + "/" + val.substring(2, 4));
                            } else {
                              setCardExpiry(val);
                            }
                          }}
                          placeholder="MM/YY"
                          maxLength={5}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2.5 px-3.5 text-slate-200 text-center font-mono focus:border-emerald-500 focus:outline-none"
                          disabled={isProcessingCheckout}
                        />
                      </div>

                      <div className="space-y-1 col-span-1">
                        <label className="text-slate-400 font-medium">CVC Code</label>
                        <input
                          type="password"
                          value={cardCvc}
                          onChange={(e) => setCardCvc(e.target.value.replace(/[^0-9]/g, ""))}
                          placeholder="123"
                          maxLength={3}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2.5 px-3.5 text-slate-200 text-center font-mono focus:border-emerald-500 focus:outline-none"
                          disabled={isProcessingCheckout}
                        />
                      </div>

                      <div className="space-y-1 col-span-1">
                        <label className="text-slate-400 font-medium">Billing ZIP</label>
                        <input
                          type="text"
                          value={cardZip}
                          onChange={(e) => setCardZip(e.target.value.replace(/[^0-9]/g, ""))}
                          placeholder="90210"
                          maxLength={5}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2.5 px-3.5 text-slate-200 text-center font-mono focus:border-emerald-500 focus:outline-none"
                          disabled={isProcessingCheckout}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Pricing Total block */}
                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs flex justify-between items-center">
                    <div>
                      <div className="text-slate-400">Selected Plan:</div>
                      <div className="font-semibold text-white text-sm">
                        {subscriptionPlans.find((p) => p.id === purchasePlan)?.name}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-slate-400 font-medium">Total Charge:</div>
                      <div className="text-base font-bold text-emerald-400">
                        ${subscriptionPlans.find((p) => p.id === purchasePlan)?.price}
                      </div>
                    </div>
                  </div>

                  {/* Buttons */}
                  <div className="flex space-x-3 pt-2">
                    <button
                      type="button"
                      onClick={() => setCheckoutStep("select")}
                      className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-semibold border border-slate-700 text-sm transition-colors cursor-pointer"
                      disabled={isProcessingCheckout}
                    >
                      Back
                    </button>
                    <button
                      type="button"
                      onClick={handlePurchaseSubscription}
                      disabled={isProcessingCheckout}
                      className="flex-[2] py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-sm transition-all shadow-lg shadow-emerald-900/10 flex items-center justify-center space-x-2 disabled:opacity-50 cursor-pointer"
                    >
                      {isProcessingCheckout ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>Authorizing simulated card...</span>
                        </>
                      ) : (
                        <>
                          <span>Pay Simulated ${subscriptionPlans.find((p) => p.id === purchasePlan)?.price}</span>
                          <CheckCircle className="w-4 h-4" />
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}

              {/* Step 3: Success Confirmation */}
              {checkoutStep === "success" && (
                <div className="text-center py-6 space-y-6">
                  <div className="flex justify-center">
                    <div className="w-16 h-16 rounded-full bg-emerald-950 border border-emerald-500 text-emerald-400 flex items-center justify-center animate-bounce shadow-lg shadow-emerald-500/10">
                      <Check className="w-8 h-8" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-bold text-white text-xl">Simulated Checkout Approved!</h4>
                    <p className="text-slate-400 text-xs">
                      The database has been updated dynamically under the acting account.
                    </p>
                  </div>

                  <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 text-xs text-left space-y-2.5 max-w-sm mx-auto">
                    <div className="flex justify-between border-b border-slate-800 pb-2">
                      <span className="text-slate-500">Receipt Status</span>
                      <span className="text-emerald-400 font-bold uppercase">PAID (SIMULATED)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Plan Tier</span>
                      <span className="text-slate-200 font-medium">
                        {subscriptionPlans.find((p) => p.id === purchasePlan)?.name}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Acting User</span>
                      <span className="text-slate-200 font-medium">@{simulatorUsername}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Account ID</span>
                      <span className="text-slate-400 font-mono">{simulatorUserId}</span>
                    </div>
                    <div className="flex justify-between border-t border-slate-800 pt-2.5">
                      <span className="text-slate-500">New Expiry</span>
                      <span className="text-emerald-400 font-mono font-semibold">
                        {purchaseExpiryDate ? new Date(purchaseExpiryDate).toLocaleDateString() : "Never"}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-3 pt-4">
                    <button
                      type="button"
                      onClick={() => setIsPurchaseModalOpen(false)}
                      className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-sm transition-all cursor-pointer"
                    >
                      Start Generating (Back to Bot)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setCheckoutStep("select");
                        setPurchasePlan("7d");
                      }}
                      className="text-xs text-slate-500 hover:text-white font-medium cursor-pointer"
                    >
                      Simulate another purchase
                    </button>
                  </div>
                </div>
              )}

            </div>

            {/* Footer */}
            <div className="bg-slate-950 p-4 border-t border-slate-800 text-center text-[10px] text-slate-500">
              🔒 Simulated Visa payment gateway for local testing purposes. No real funds are moved.
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
