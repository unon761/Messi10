import os
from dotenv import load_dotenv

load_dotenv()

CONFIG = {
    "BOT_TOKEN": os.getenv("BOT_TOKEN") or os.getenv("TELEGRAM_BOT_TOKEN") or "",
    "GROQ_API_KEY": os.getenv("GROQ_API_KEY") or "",
    "GEMINI_API_KEY": os.getenv("GEMINI_API_KEY") or "",
    "ADMIN_ID": os.getenv("ADMIN_ID") or "7568676840",
    "FREE_COINS_LIMIT": 3,
    "GENERATION_COST": 4,
    "DB_FILE": os.path.join(os.getcwd(), "database.json"),
    "TEMP_DIR": os.path.join(os.getcwd(), "temp"),
}

os.makedirs(CONFIG["TEMP_DIR"], exist_ok=True)
