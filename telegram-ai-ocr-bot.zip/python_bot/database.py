import os
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from python_bot.config import CONFIG

logger = logging.getLogger("PogoBot.Database")

def load_db() -> Dict[str, Any]:
    default_db = {
        "users": [],
        "description_history": [],
        "temporary_upload_queue": [],
        "settings": {"group_chat_id": None}
    }
    if not os.path.exists(CONFIG["DB_FILE"]):
        save_db(default_db)
        return default_db
    try:
        with open(CONFIG["DB_FILE"], "r", encoding="utf-8") as f:
            data = json.load(f)
            if "users" not in data: data["users"] = []
            if "description_history" not in data: data["description_history"] = []
            if "temporary_upload_queue" not in data: data["temporary_upload_queue"] = []
            if "settings" not in data: data["settings"] = {"group_chat_id": None}
            return data
    except Exception as e:
        logger.error(f"Error loading database.json: {e}")
        return default_db

def save_db(data: Dict[str, Any]) -> None:
    try:
        with open(CONFIG["DB_FILE"], "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        logger.error(f"Error saving database.json: {e}")

def is_subscription_active(expiry_str: Optional[str]) -> bool:
    if not expiry_str:
        return False
    try:
        expiry_dt = datetime.fromisoformat(expiry_str.replace("Z", "+00:00"))
        now_dt = datetime.now(expiry_dt.tzinfo) if expiry_dt.tzinfo else datetime.now()
        return expiry_dt > now_dt
    except Exception:
        return False

def get_or_create_user(user_id: str, username: str = "Trainer") -> Dict[str, Any]:
    db = load_db()
    for user in db["users"]:
        if str(user["id"]) == str(user_id):
            if username and user.get("username") != username:
                user["username"] = username
                save_db(db)
            return user

    new_user = {
        "id": str(user_id),
        "username": username,
        "coins": 0,
        "free_trials_remaining": CONFIG["FREE_COINS_LIMIT"],
        "subscription_expiry": None,
        "descriptions_generated": 0,
        "join_date": datetime.utcnow().isoformat() + "Z"
    }
    db["users"].append(new_user)
    save_db(db)
    return new_user

def add_coins(user_id: str, amount: int) -> Dict[str, Any]:
    db = load_db()
    user = get_or_create_user(user_id)
    for u in db["users"]:
        if str(u["id"]) == str(user_id):
            u["coins"] += amount
            save_db(db)
            return u
    return user

def remove_coins(user_id: str, amount: int) -> Dict[str, Any]:
    db = load_db()
    user = get_or_create_user(user_id)
    for u in db["users"]:
        if str(u["id"]) == str(user_id):
            u["coins"] = max(0, u["coins"] - amount)
            save_db(db)
            return u
    return user

def add_subscription(user_id: str, plan: str) -> str:
    db = load_db()
    user = get_or_create_user(user_id)
    days_map = {"1d": 1, "3d": 3, "7d": 7, "31d": 31, "365d": 365}
    days = days_map.get(plan.lower(), 1)

    base_dt = datetime.utcnow()
    if user.get("subscription_expiry") and is_subscription_active(user["subscription_expiry"]):
        try:
            base_dt = datetime.fromisoformat(user["subscription_expiry"].replace("Z", ""))
        except Exception:
            pass

    new_expiry_dt = base_dt + timedelta(days=days)
    new_expiry_str = new_expiry_dt.isoformat() + "Z"

    for u in db["users"]:
        if str(u["id"]) == str(user_id):
            u["subscription_expiry"] = new_expiry_str
            save_db(db)
            return new_expiry_str
    return new_expiry_str

def remove_subscription(user_id: str) -> None:
    db = load_db()
    for u in db["users"]:
        if str(u["id"]) == str(user_id):
            u["subscription_expiry"] = None
            save_db(db)
            return

def get_queue(user_id: str) -> List[Dict[str, Any]]:
    db = load_db()
    return [item for item in db["temporary_upload_queue"] if str(item["user_id"]) == str(user_id)]

def add_to_queue(user_id: str, file_path: str) -> None:
    db = load_db()
    next_id = max([item.get("id", 0) for item in db["temporary_upload_queue"]], default=0) + 1
    new_item = {
        "id": next_id,
        "user_id": str(user_id),
        "file_path": file_path,
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }
    db["temporary_upload_queue"].append(new_item)
    save_db(db)

def clear_queue(user_id: str) -> None:
    db = load_db()
    user_queue = [item for item in db["temporary_upload_queue"] if str(item["user_id"]) == str(user_id)]
    for item in user_queue:
        file_path = item.get("file_path")
        if file_path and os.path.exists(file_path):
            try:
                os.remove(file_path)
            except Exception as e:
                logger.error(f"Error removing temp file {file_path}: {e}")
    db["temporary_upload_queue"] = [item for item in db["temporary_upload_queue"] if str(item["user_id"]) != str(user_id)]
    save_db(db)

def add_history(user_id: str, screenshots_count: int, description: str) -> None:
    db = load_db()
    next_id = max([item.get("id", 0) for item in db["description_history"]], default=0) + 1
    new_history = {
        "id": next_id,
        "user_id": str(user_id),
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "screenshots_count": screenshots_count,
        "description": description
    }
    db["description_history"].append(new_history)

    # Deduct coins or free trial
    for u in db["users"]:
        if str(u["id"]) == str(user_id):
            u["descriptions_generated"] += 1
            if not is_subscription_active(u.get("subscription_expiry")):
                if u.get("free_trials_remaining", 0) > 0:
                    u["free_trials_remaining"] -= 1
                else:
                    u["coins"] = max(0, u.get("coins", 0) - CONFIG["GENERATION_COST"])
            break
    save_db(db)

def get_history(user_id: str) -> List[Dict[str, Any]]:
    db = load_db()
    user_history = [item for item in db["description_history"] if str(item["user_id"]) == str(user_id)]
    user_history.sort(key=lambda x: x.get("id", 0), reverse=True)
    return user_history

def get_group_chat_id() -> Optional[str]:
    db = load_db()
    return db.get("settings", {}).get("group_chat_id") or os.getenv("TELEGRAM_GROUP_ID")

def set_group_chat_id(chat_id: Optional[str]) -> None:
    db = load_db()
    if "settings" not in db:
        db["settings"] = {}
    db["settings"]["group_chat_id"] = str(chat_id) if chat_id else None
    save_db(db)
